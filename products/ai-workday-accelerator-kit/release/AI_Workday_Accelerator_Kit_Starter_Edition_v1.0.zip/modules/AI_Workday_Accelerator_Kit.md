# FlowOps AI

## Enterprise Productivity Suite

Version: Starter Edition 1.0

---

## Overview

Stop writing repetitive business documents from scratch.

Build executive-ready deliverables in minutes using enterprise-grade AI Business Systems.

Designed for professionals who need better outputs, faster.

---

## What You'll Achieve

- Reduce repetitive work
- Improve document quality
- Standardize business deliverables
- Accelerate executive reporting
- Produce professional outputs with AI
- Save more than 100 hours every year

---

# Modules

The Suite includes 25 Enterprise Business Systems organized into five professional collections.

## Excel Intelligence

Business systems focused on analysis, reporting and executive dashboards.

Includes:

- Monthly Financial Closing
- Executive KPI Reporting
- Sales Performance Analysis
- Budget Variance Analysis
- Operational Dashboard Creation

---

## Technical Documentation

Professional documentation systems for enterprise environments.

Includes:

- OAuth Integration Documentation
- REST API Documentation
- Enterprise Procedures
- Root Cause Analysis
- Knowledge Transfer

---

## IT Troubleshooting

Structured systems for diagnosing production problems.

Includes:

- Production Incident Investigation
- Enterprise Log Analysis
- Performance Bottleneck Investigation
- Critical Error Diagnosis
- Disaster Recovery Planning

---

## Project Delivery

Enterprise project management systems.

Includes:

- Project Kickoff
- Weekly Status Reporting
- Project Risk Assessment
- Stakeholder Communication
- Lessons Learned

---

## Executive Productivity

Decision support systems for executives.

Includes:

- Executive Decision Memo
- Executive Presentation Builder
- Weekly Leadership Summary
- Executive Email Assistant
- Strategic Meeting Preparation

---

# At a Glance

- 25 Enterprise Business Systems
- 25 Professional AI Workflows
- 25 Executive Frameworks
- 25 Validation Checklists
- 25 Ready-to-use Deliverables
- Works with ChatGPT
- Works with Claude
- Works with Gemini
- Works with Microsoft Copilot

---

# Who Is This Product For?

Ideal for:

- Business Analysts
- Solution Architects
- Project Managers
- Technical Consultants
- Enterprise Support Engineers
- IT Managers
- Operations Managers
- PMO Teams
- Team Leaders
- Business Consultants

---

# Expected Benefits

Produce executive-ready documents.

Reduce repetitive documentation.

Improve consistency.

Accelerate project delivery.

Increase professional writing quality.

Support better executive decisions.

---

# Estimated Time Savings

Typical users recover between 100 and 250 working hours every year depending on how frequently the systems are used.

---

# Requirements

Recommended AI platforms:

- ChatGPT
- Claude
- Gemini
- Microsoft Copilot

No programming knowledge required.

---

# Included

- README
- Quick Start Guide
- 25 Business Systems
- Professional Prompts
- Validation Checklists
- Professional Frameworks
- Ready-to-use Templates
- Examples
- Bonus Material

---

# License

Single User License.

Commercial use of generated outputs is permitted.

Resale or redistribution of this product is prohibited.

---

Built for professionals.

Designed for enterprise work.

Powered by FlowOps AI.

---

# Quick Start Guide

## Welcome

Welcome to the **FlowOps AI – Enterprise Productivity Suite**.

This suite has been designed to help business professionals produce executive-quality deliverables using AI in a structured, repeatable and professional way.

Unlike generic prompt libraries, every Business System guides you through an entire business workflow—from understanding the problem to producing a polished deliverable.

---

# Your Workflow

Every Business System follows the same methodology.

```
Business Context
        ↓
Business Objective
        ↓
Professional AI Workflow
        ↓
AI Generated Draft
        ↓
Validation Checklist
        ↓
Executive-Ready Deliverable
```

Following this process consistently produces significantly better results than copying isolated prompts.

---

# Step 1 — Select the Appropriate Business System

Choose the Business System that best matches your current objective.

Examples:

- Need to document an OAuth integration?
  → OAuth Integration Documentation System

- Need to investigate a production issue?
  → Production Incident Investigation System

- Need an executive weekly report?
  → Weekly Leadership Summary System

Do not try to adapt unrelated Business Systems.

---

# Step 2 — Prepare Your Business Context

Before opening your AI assistant, collect the information required for your task.

Typical information includes:

- Business objective
- Current situation
- Constraints
- Stakeholders
- Available data
- Expected outcome

The more context you provide, the more valuable the generated output will be.

---

# Step 3 — Use the Professional AI Workflow

Every Business System contains a Professional AI Workflow.

Copy it into your preferred AI platform.

Recommended platforms:

- ChatGPT
- Claude
- Gemini
- Microsoft Copilot

Then provide your business context below the workflow.

---

# Step 4 — Review the AI Output

Do not assume the first response is final.

Review the generated content against:

- Business objective
- Accuracy
- Completeness
- Consistency
- Professional language
- Organizational terminology

Most deliverables improve significantly after one or two refinement cycles.

---

# Step 5 — Validate the Deliverable

Every Business System includes a Validation Checklist.

Use it before considering the document complete.

Typical validation questions include:

- Is the objective clearly addressed?
- Are recommendations actionable?
- Are assumptions documented?
- Is the audience appropriate?
- Can another professional understand the document without additional explanation?

---

# Step 6 — Adapt to Your Organization

Customize the final output to match your organization's:

- Terminology
- Documentation standards
- Governance model
- Approval process
- Communication style

The suite is designed to accelerate professional work—not replace professional judgment.

---

# Best Practices

For the highest-quality results:

✓ Always provide business context.

✓ Be specific.

✓ Include real constraints.

✓ Request executive-level writing.

✓ Ask AI to explain assumptions.

✓ Review before publishing.

✓ Save improved versions for future reuse.

---

# Common Mistakes

Avoid:

- Copying prompts without context.
- Asking vague questions.
- Skipping the validation checklist.
- Using generic terminology.
- Accepting the first AI response without review.

---

# Typical Results

Most users report improvements such as:

- Faster documentation.
- Better report quality.
- More consistent deliverables.
- Reduced repetitive work.
- Improved executive communication.
- Higher confidence in AI-generated outputs.

---

# Recommended Usage

Use the suite as part of your daily professional workflow.

Instead of asking AI to "write something", start with the appropriate Business System, provide your business context and follow the complete workflow.

This approach consistently produces more accurate, professional and reusable results.

---

# Need Better Results?

The quality of AI output is directly proportional to the quality of the information you provide.

Good context produces good deliverables.

Excellent context produces executive-ready deliverables.

Use this suite as a professional framework rather than a simple prompt collection.

---

# Productivity Results Framework

## The Value Is in the Time You Recover

FlowOps AI is designed around a simple principle:

> The value of an AI workflow is not the prompt itself. The value is the professional work it helps you complete faster and more consistently.

The examples below illustrate **potential productivity scenarios**. They are not customer testimonials or guaranteed results.

Actual savings depend on task complexity, available information, review requirements and frequency of use.

---

# Example 1 — Weekly Executive Status Report

## Before

A project manager manually:

- Reviews project notes.
- Consolidates workstream updates.
- Identifies risks.
- Writes the executive summary.
- Formats the report.
- Reviews the final document.

### Illustrative effort

**3 hours**

---

## With the Business System

The project manager provides:

- Weekly project information.
- Milestone status.
- Risks.
- Issues.
- Decisions required.

The Business System generates a structured first draft containing:

- Executive Summary
- Project Health
- Achievements
- Risks
- Issues
- Decisions
- Next-Week Priorities

The professional then reviews and adapts the result.

### Illustrative effort

**45 minutes**

---

## Potential Saving

**2 hours 15 minutes per report**

At four reports per month:

**9 hours/month**

At twelve months:

**108 hours/year**

---

# Example 2 — Technical Documentation

## Before

A technical consultant starts with a blank document.

The consultant must determine:

- Document structure.
- Required sections.
- Technical scope.
- Security considerations.
- Operational considerations.
- Support information.

### Illustrative effort

**6 hours**

---

## With the Business System

The consultant provides the technical context and uses the appropriate documentation workflow.

The system produces a structured first draft covering:

- Executive Summary
- Architecture
- Functional Behaviour
- Configuration
- Security
- Operations
- Support
- Risks
- Recommendations

The consultant reviews the technical accuracy and adapts the final document.

### Illustrative effort

**90 minutes**

---

## Potential Saving

**4.5 hours per document**

At two documents per month:

**9 hours/month**

At twelve months:

**108 hours/year**

---

# Example 3 — Production Incident Investigation

## Before

An engineer must manually organize:

- Incident timeline.
- Logs.
- Evidence.
- Business impact.
- Technical findings.
- Root cause.
- Corrective actions.

### Illustrative effort

**5 hours**

---

## With the Business System

The engineer provides the available evidence and incident context.

The system structures the investigation into:

- Executive Summary
- Business Impact
- Timeline
- Technical Investigation
- Evidence
- Root Cause
- Corrective Actions
- Preventive Actions

The engineer validates every technical conclusion against the evidence.

### Illustrative effort

**60 minutes**

---

## Potential Saving

**4 hours per incident**

At two major investigations per month:

**8 hours/month**

At twelve months:

**96 hours/year**

---

# Example 4 — Executive Decision Memo

## Before

A manager spends time:

- Gathering information.
- Structuring alternatives.
- Comparing risks.
- Preparing recommendations.
- Writing the executive document.

### Illustrative effort

**3 hours**

---

## With the Business System

The manager provides:

- Business situation.
- Alternatives.
- Costs.
- Risks.
- Constraints.
- Desired outcome.

The system produces a structured decision memo.

### Illustrative effort

**40 minutes**

---

## Potential Saving

**2 hours 20 minutes per decision**

At two decisions per month:

**4 hours 40 minutes/month**

Approximately:

**56 hours/year**

---

# Example 5 — Knowledge Transfer Package

## Before

A technical team preparing a project handover manually documents:

- Business context.
- Architecture.
- Components.
- Integrations.
- Operations.
- Support procedures.
- Known issues.
- Escalation paths.

### Illustrative effort

**8 hours**

---

## With the Business System

The team provides the solution information and operational context.

The system generates a structured knowledge-transfer package that can then be technically reviewed and completed.

### Illustrative effort

**90 minutes**

---

## Potential Saving

**6.5 hours per handover**

At four handovers per year:

**26 hours/year**

---

# Combined Illustrative Scenario

Consider a professional who regularly performs these activities.

| Activity | Illustrative Annual Saving |
|---|---:|
| Weekly Executive Reports | 108 hours |
| Technical Documentation | 108 hours |
| Incident Investigations | 96 hours |
| Executive Decision Memos | 56 hours |
| Knowledge Transfer | 26 hours |
| **Total** | **394 hours** |

This is an **illustrative scenario**, not a promise of 394 hours saved.

Actual productivity gains will vary significantly by role and workload.

---

# Convert Time Into Business Value

Time saved can be translated into an approximate productivity value.

For example:

If one hour of professional time is valued internally at **$30**, then:

**100 hours recovered × $30 = $3,000 of productive capacity**

If one hour is valued at **$50**:

**100 hours × $50 = $5,000**

If one hour is valued at **$75**:

**100 hours × $75 = $7,500**

The appropriate calculation depends on the organization's labor cost, billing rate or opportunity cost.

---

# Calculate Your Own Potential

Use:

**Annual Hours Saved × Value of One Professional Hour = Potential Productivity Value**

Example:

**120 hours × $50 = $6,000**

This does not necessarily represent direct cash savings.

It represents the potential value of professional capacity recovered for higher-value work.

---

# The Important Metric

Don't measure AI productivity by:

> "How many prompts did I use?"

Measure it by:

> "How much valuable professional work did I complete that I would otherwise have spent hours producing manually?"

That is the real productivity opportunity.

---

# How to Measure Your Results

For your first 30 days, record:

- Task
- Time without AI
- Time with AI
- Review time
- Final output quality
- Rework required

Example:

| Task | Without AI | With AI | Saving |
|---|---:|---:|---:|
| Weekly report | 180 min | 45 min | 135 min |
| Technical document | 360 min | 90 min | 270 min |
| Executive memo | 180 min | 40 min | 140 min |

After several weeks, calculate your actual average.

---

# Important

These examples are **illustrative productivity scenarios**.

They are not:

- Customer testimonials.
- Guaranteed results.
- Independent benchmark studies.
- Claims of specific customer performance.

Your results will depend on:

- Your role.
- Task complexity.
- Quality of available information.
- AI platform.
- Review requirements.
- Frequency of use.
- Your organization's processes.

---

# The Goal

The objective is simple:

**Spend less time producing repetitive professional work and more time applying your expertise where it creates greater value.**

FlowOps AI provides the framework.

Your professional judgment remains the final layer.

---

# Bonus: 100 Enterprise AI Writing Principles

## Introduction

Professional AI output depends on more than the prompt.

The quality of the result is influenced by the business context, structure, audience, evidence, constraints and review process provided to the AI.

These 100 principles are designed to help professionals consistently produce clearer, more accurate and more useful business deliverables.

---

# 1. Business Context

### 01. Define the business problem first.
AI produces better results when it understands the problem before being asked to create the deliverable.

### 02. State the desired business outcome.
Describe what success should look like.

### 03. Explain why the work matters.
Business relevance improves prioritization and recommendations.

### 04. Identify the affected stakeholders.
Different stakeholders require different information.

### 05. Define the target audience.
An executive report should not read like a technical investigation.

### 06. Provide relevant constraints.
Time, budget, technology, compliance and organizational constraints influence recommendations.

### 07. Identify dependencies.
Recommendations should consider systems, teams, vendors and processes that affect execution.

### 08. Define the scope.
Clearly state what is included and excluded.

### 09. State assumptions explicitly.
Unstated assumptions create unreliable conclusions.

### 10. Describe the current state.
AI needs to understand where the organization is before recommending where it should go.

---

# 2. Prompt Structure

### 11. Assign an appropriate professional role.
Use a role that matches the business problem.

### 12. Define the objective.
Tell AI exactly what it must accomplish.

### 13. Specify the deliverable.
Request a report, memo, plan, analysis or another concrete output.

### 14. Define the audience.
Audience determines tone, depth and terminology.

### 15. Define the required sections.
Structure produces more consistent outputs.

### 16. Define the desired level of detail.
Avoid leaving depth entirely to interpretation.

### 17. Specify the tone.
Professional, executive, technical or instructional language should be explicitly requested.

### 18. Define quality criteria.
Tell AI how the output will be evaluated.

### 19. Define unacceptable behaviour.
For example, instruct AI not to invent facts.

### 20. Define the final format.
Markdown, table, report, checklist or presentation outline can be specified.

---

# 3. Accuracy

### 21. Separate facts from assumptions.
Never allow assumptions to appear as confirmed information.

### 22. Ask AI to identify missing information.
Missing data should be visible.

### 23. Never treat generated information as automatically correct.
Professional review remains necessary.

### 24. Validate numerical information.
Check calculations independently when accuracy matters.

### 25. Validate technical recommendations.
AI should support technical judgment, not replace it.

### 26. Identify uncertainty.
Ask AI to explicitly identify areas where evidence is insufficient.

### 27. Preserve source information.
Maintain references to the original data when appropriate.

### 28. Avoid unsupported claims.
Every significant conclusion should have evidence or clearly stated assumptions.

### 29. Request confidence levels when appropriate.
Confidence can help prioritize human review.

### 30. Review high-impact decisions manually.
Business-critical decisions require professional validation.

---

# 4. Executive Writing

### 31. Lead with the conclusion.
Executives should understand the main message quickly.

### 32. Put business impact before technical detail.
Explain why something matters before explaining how it works.

### 33. Keep executive summaries concise.
The summary should communicate the essential information.

### 34. Make recommendations explicit.
Do not force executives to infer the recommended action.

### 35. Identify decisions required.
A report should clearly state what leadership must decide.

### 36. Quantify impact whenever possible.
Numbers often communicate significance more effectively than adjectives.

### 37. Highlight material risks.
Do not overwhelm executives with low-impact information.

### 38. Separate information from action.
Make required actions visually and logically clear.

### 39. Use direct language.
Avoid unnecessary corporate jargon.

### 40. End with clear next steps.
Every executive document should lead toward action.

---

# 5. Technical Documentation

### 41. Explain the purpose before the implementation.
Readers need context before technical details.

### 42. Define technical terminology.
Do not assume every reader has the same background.

### 43. Document architecture decisions.
Explain why important decisions were made.

### 44. Document operational responsibilities.
A solution is incomplete without ownership.

### 45. Include failure scenarios.
Happy-path documentation is insufficient.

### 46. Document configuration dependencies.
Configuration often determines system behaviour.

### 47. Explain authentication and authorization separately.
They solve different problems.

### 48. Document interfaces explicitly.
Interfaces are critical for maintenance and integration.

### 49. Include troubleshooting guidance.
Technical documentation should support operations.

### 50. Maintain version history.
Documentation must evolve with the solution.

---

# 6. Project Management

### 51. Define measurable objectives.
Avoid objectives that cannot be evaluated.

### 52. Separate risks from issues.
A risk may happen; an issue is already happening.

### 53. Assign owners.
Every significant action should have a responsible person or role.

### 54. Define deadlines.
Actions without dates are difficult to manage.

### 55. Track decisions.
Important project decisions should be recorded.

### 56. Communicate changes early.
Delayed communication increases project risk.

### 57. Focus status reports on outcomes.
Activities alone do not communicate project health.

### 58. Quantify progress.
Use measurable indicators where possible.

### 59. Identify dependencies.
Dependencies frequently explain project delays.

### 60. Review assumptions continuously.
Project assumptions can become risks as circumstances change.

---

# 7. Troubleshooting

### 61. Preserve evidence before changing the system.
Evidence can disappear after remediation.

### 62. Establish a timeline.
Chronology is one of the strongest troubleshooting tools.

### 63. Start with observable symptoms.
Do not begin with an unverified theory.

### 64. Generate multiple hypotheses.
Avoid anchoring on the first explanation.

### 65. Test hypotheses systematically.
Use evidence to confirm or reject them.

### 66. Correlate multiple sources.
Application logs alone may not explain a distributed failure.

### 67. Distinguish symptoms from causes.
The first visible error may not be the root cause.

### 68. Document temporary mitigations.
Temporary fixes should not disappear from institutional knowledge.

### 69. Identify recurrence mechanisms.
Understand why the incident could happen again.

### 70. Convert findings into preventive actions.
The investigation should improve future reliability.

---

# 8. AI Workflow Design

### 71. Use AI for structure.
AI is particularly effective at organizing complex information.

### 72. Use AI for first drafts.
Professionals should perform the final review.

### 73. Use iterative refinement.
The first output should be treated as a draft.

### 74. Ask AI to critique its own output.
A separate review pass can reveal weaknesses.

### 75. Use checklists.
Checklists convert subjective review into repeatable quality control.

### 76. Reuse successful workflows.
Save workflows that consistently produce valuable results.

### 77. Build specialized workflows.
Specific business problems usually benefit from specialized instructions.

### 78. Avoid excessive prompt complexity.
A longer prompt is not automatically a better prompt.

### 79. Provide examples when style matters.
Examples help establish expectations.

### 80. Separate generation from validation.
Creating content and evaluating content are different activities.

---

# 9. Professional Productivity

### 81. Measure time before using AI.
You need a baseline to understand productivity improvement.

### 82. Measure review time.
Generated content still requires professional validation.

### 83. Measure rework.
Fast initial generation is not useful if it creates extensive corrections.

### 84. Track recurring tasks.
Repeated tasks are strong candidates for AI workflows.

### 85. Prioritize high-frequency work.
Saving small amounts of time repeatedly can create substantial annual value.

### 86. Prioritize high-effort work.
Large documentation tasks can produce significant productivity gains.

### 87. Standardize recurring deliverables.
Consistency reduces cognitive overhead.

### 88. Build reusable context.
Common organizational information can accelerate future work.

### 89. Create organizational templates.
Reusable frameworks reduce unnecessary reinvention.

### 90. Measure business value, not prompt usage.
The objective is improved professional productivity.

---

# 10. Quality and Governance

### 91. Maintain human accountability.
AI-generated content requires responsible professional ownership.

### 92. Protect confidential information.
Only provide information that your organization's policies permit.

### 93. Review sensitive outputs carefully.
Security, financial, legal and operational content deserves additional scrutiny.

### 94. Establish approval requirements.
Important deliverables should have defined review processes.

### 95. Maintain consistent terminology.
Terminology inconsistency reduces professional credibility.

### 96. Record important assumptions.
Future readers need to understand the reasoning behind decisions.

### 97. Review workflows periodically.
Business processes change.

### 98. Retire obsolete workflows.
Outdated frameworks can create incorrect outputs.

### 99. Measure actual results.
Replace assumptions with observed productivity data over time.

### 100. Keep professional judgment in control.
AI accelerates professional work; it does not replace accountability.

---

# Final Principle

The most effective use of AI in professional environments is not:

> "Ask AI to do my work."

It is:

> "Give AI a structured business workflow, provide the right context, validate the result and use the recovered time for higher-value work."

That is the foundation of sustainable AI productivity.

---

# Monthly Financial Closing System

## Executive Summary

The Monthly Financial Closing System provides a structured methodology for organizing, analyzing and communicating monthly financial closing activities using AI.

It helps finance and business professionals transform raw financial information into structured management analysis, identify significant variances and prepare executive-ready closing reports.

The system is designed to accelerate analysis while keeping financial validation and professional judgment under human control.

---

## Business Problem

Monthly financial closing often requires significant manual effort to consolidate information, investigate variances and prepare management reports.

Common challenges include:

- Manual consolidation of financial information.
- Repetitive variance analysis.
- Time-consuming report preparation.
- Inconsistent explanations.
- Difficulty identifying significant deviations.
- Delayed executive reporting.

---

## Business Objective

Produce a structured monthly financial closing analysis that identifies relevant financial movements, explains significant variances and prepares management-ready conclusions.

---

## Typical Enterprise Scenario

A finance team has completed the monthly accounting close.

The available information includes:

- Current-period actuals.
- Previous-period actuals.
- Budget.
- Forecast.
- Revenue.
- Expenses.
- Operational indicators.

Management requires a concise analysis explaining the most significant movements and their potential business implications.

---

## Professional AI Workflow

### Step 1 — Define the Reporting Period

Document:

- Current period.
- Comparison period.
- Fiscal year.
- Reporting currency.
- Business unit.
- Reporting scope.

### Step 2 — Prepare Financial Data

Provide:

- Actual results.
- Budget.
- Forecast.
- Prior-period results.
- Relevant operational metrics.

Ensure the data is complete and validated before analysis.

### Step 3 — Identify Significant Variances

Analyze:

- Absolute variance.
- Percentage variance.
- Trend changes.
- Material movements.
- Unexpected results.

Prioritize material deviations rather than reporting every movement.

### Step 4 — Investigate Variances

For significant deviations identify:

- Possible business drivers.
- Operational factors.
- One-time events.
- Volume changes.
- Price changes.
- Cost changes.
- Timing effects.

Clearly distinguish confirmed explanations from hypotheses.

### Step 5 — Executive Interpretation

Translate financial movements into business implications.

Explain:

- What changed.
- Why it changed.
- Why it matters.
- Whether action is required.

### Step 6 — Management Recommendations

Define:

- Immediate actions.
- Areas requiring investigation.
- Forecast adjustments.
- Cost-control opportunities.
- Revenue opportunities.

### Step 7 — Prepare Closing Summary

Produce:

- Executive Summary.
- Financial Highlights.
- Significant Variances.
- Key Drivers.
- Risks.
- Recommendations.
- Management Actions.

---

# Professional AI Prompt

You are a Senior Financial Analyst specializing in management reporting and financial performance analysis.

Analyze the supplied monthly financial closing information.

Produce an executive-ready financial closing analysis including:

- Executive Summary
- Revenue Analysis
- Expense Analysis
- Budget vs Actual
- Forecast vs Actual
- Prior Period Comparison
- Significant Variances
- Variance Drivers
- Financial Risks
- Business Implications
- Management Recommendations
- Action Items

Follow these rules:

1. Do not invent financial data.
2. Do not assume explanations that are not supported by the available information.
3. Clearly distinguish confirmed facts from hypotheses.
4. Highlight material variances.
5. Use tables where they improve readability.
6. Explain financial results using business language.
7. Identify missing information required for stronger conclusions.

---

# Required Input Information

Collect:

- Reporting period.
- Current actuals.
- Previous-period actuals.
- Budget.
- Forecast.
- Relevant financial categories.
- Business-unit information.
- Available explanations for significant variances.
- Management priorities.

---

# Expected Deliverables

Generate:

- Monthly Financial Closing Report.
- Executive Summary.
- Variance Analysis.
- Financial Highlights.
- Risk Summary.
- Management Recommendations.
- Action Register.

---

# Validation Checklist

Verify:

- Reporting period is correct.
- Financial data is complete.
- Budget comparisons are accurate.
- Variances are calculated correctly.
- Significant movements are identified.
- Explanations are supported by evidence.
- Assumptions are clearly identified.
- Recommendations are actionable.
- No financial information has been fabricated.

---

# Common Mistakes

Avoid:

- Treating every variance as significant.
- Inventing explanations.
- Ignoring material movements.
- Reporting numbers without interpretation.
- Mixing actuals with forecasts.
- Presenting hypotheses as confirmed facts.
- Providing recommendations without identifying the underlying issue.

---

# Best Practices

- Establish materiality thresholds.
- Compare multiple periods.
- Separate recurring and one-time effects.
- Combine financial and operational indicators.
- Focus management attention on significant movements.
- Validate calculations independently.
- Maintain an audit trail for important conclusions.

---

# Business Value

Organizations benefit from:

- Faster monthly closing analysis.
- More consistent management reporting.
- Earlier identification of financial risks.
- Better executive visibility.
- Reduced repetitive analysis.
- Improved decision support.

---

# Estimated Time Savings

Illustrative productivity improvement:

**2 to 5 hours per monthly closing cycle**, depending on the size and complexity of the organization.

Actual savings depend on data preparation, reporting requirements and review processes.

---

# Expert Recommendations

AI should accelerate financial analysis, not replace financial controls.

All calculations, accounting conclusions and management decisions should be validated by the appropriate finance professionals before official reporting.

The greatest value comes from using AI to reduce repetitive analytical work while allowing finance professionals to spend more time investigating material business drivers and supporting management decisions.

---

# Executive KPI Reporting System

## Executive Summary

The Executive KPI Reporting System provides a structured methodology for transforming operational and business performance data into concise executive reporting.

It helps professionals identify the metrics that matter, interpret performance trends, highlight deviations and translate quantitative information into actionable management insights.

The system is designed to reduce manual reporting effort while improving consistency, clarity and decision support.

---

## Business Problem

Executive reporting often becomes a collection of disconnected metrics without clear interpretation.

Common challenges include:

- Too many KPIs.
- Inconsistent reporting formats.
- Manual consolidation.
- Difficulty identifying meaningful trends.
- Metrics without business context.
- Excessive operational detail.
- Delayed management decisions.

---

## Business Objective

Create an executive KPI report that focuses leadership attention on the organization's most important performance indicators, explains significant changes and identifies actions requiring management attention.

---

## Typical Enterprise Scenario

A management team receives weekly or monthly performance information from several business areas.

The available information includes:

- Revenue.
- Costs.
- Sales.
- Customer metrics.
- Operational metrics.
- Service levels.
- Productivity.
- Project performance.

Leadership needs a concise report that explains what changed, why it matters and where action is required.

---

# Professional AI Workflow

## Step 1 — Define the Executive Objective

Document:

- Reporting period.
- Business area.
- Executive audience.
- Strategic priorities.
- Desired decisions.

---

## Step 2 — Identify Relevant KPIs

Classify available metrics into categories such as:

- Financial.
- Customer.
- Operational.
- Commercial.
- Productivity.
- Quality.
- Strategic.

Do not include metrics simply because they are available.

---

## Step 3 — Define KPI Structure

For each KPI document:

- KPI name.
- Definition.
- Current value.
- Target.
- Previous value.
- Variance.
- Trend.
- Business owner.

---

## Step 4 — Analyze Performance

Identify:

- Positive performance.
- Negative performance.
- Significant deviations.
- Emerging trends.
- Persistent problems.
- Unexpected movements.

---

## Step 5 — Interpret Business Impact

For every significant KPI movement explain:

- What changed?
- Why does it matter?
- What may be driving the change?
- What is the potential business impact?
- Is action required?

Clearly distinguish confirmed information from hypotheses.

---

## Step 6 — Prioritize Executive Attention

Classify findings as:

### Monitor

Performance is within expected parameters.

### Attention Required

Performance requires management review.

### Immediate Action

Performance presents a material business concern.

---

## Step 7 — Prepare Executive Report

Generate:

- Executive Summary.
- KPI Dashboard.
- Key Performance Highlights.
- Significant Variances.
- Trend Analysis.
- Risks.
- Recommended Actions.
- Management Decisions Required.

---

# Professional AI Prompt

You are a Senior Business Performance Analyst specializing in executive KPI reporting.

Analyze the supplied business performance information and create an executive-ready KPI report.

Include:

- Executive Summary.
- KPI Dashboard.
- Current Performance.
- Target Comparison.
- Previous Period Comparison.
- Trend Analysis.
- Significant Variances.
- Business Drivers.
- Risks.
- Recommended Actions.
- Decisions Required.

Follow these rules:

1. Do not invent KPI values.
2. Do not create explanations unsupported by the provided information.
3. Clearly identify missing data.
4. Distinguish facts from hypotheses.
5. Prioritize material business movements.
6. Avoid unnecessary operational detail.
7. Translate metrics into business implications.
8. Use tables where appropriate.

---

# Required Input Information

Collect:

- Reporting period.
- KPI catalogue.
- Current values.
- Targets.
- Previous-period values.
- Historical values when available.
- KPI definitions.
- Business owners.
- Known business drivers.
- Strategic priorities.

---

# Expected Deliverables

Generate:

- Executive KPI Report.
- KPI Dashboard Structure.
- Performance Summary.
- Variance Analysis.
- Trend Analysis.
- Risk Summary.
- Management Action Plan.
- Executive Decision List.

---

# Validation Checklist

Verify:

- KPI definitions are clear.
- Reporting period is correct.
- Current values are accurate.
- Targets are correctly identified.
- Variances are calculated correctly.
- Trends are supported by available historical data.
- Significant deviations are identified.
- Business implications are clearly explained.
- Recommendations are actionable.
- No information has been fabricated.

---

# Common Mistakes

Avoid:

- Reporting too many KPIs.
- Treating every metric as equally important.
- Showing numbers without interpretation.
- Comparing incompatible periods.
- Creating unsupported explanations.
- Ignoring KPI definitions.
- Mixing strategic and operational indicators without distinction.

---

# Best Practices

- Limit executive dashboards to meaningful KPIs.
- Define every KPI consistently.
- Establish target values.
- Compare current performance against historical trends.
- Use thresholds to highlight exceptions.
- Focus management attention on material deviations.
- Connect KPIs to strategic objectives.
- Maintain consistent reporting periods.

---

# Business Value

Organizations benefit from:

- Faster executive reporting.
- Better visibility into business performance.
- Earlier identification of negative trends.
- More consistent management reporting.
- Reduced manual analysis.
- Better executive decision support.

---

# Estimated Time Savings

Illustrative productivity improvement:

**2 to 4 hours per reporting cycle**, depending on the number of KPIs, data sources and reporting requirements.

Actual savings depend on data preparation and validation requirements.

---

# Expert Recommendations

A KPI dashboard should not attempt to display everything the organization measures.

Its purpose is to focus executive attention on the indicators that best explain organizational performance and strategic progress.

The strongest KPI reports connect three elements:

**Metric → Business Meaning → Management Action**

A number without interpretation creates information.

A number connected to business impact and action creates decision support.

---

# Sales Performance Analysis System

## Executive Summary

The Sales Performance Analysis System provides a structured methodology for analyzing commercial performance, identifying revenue trends and explaining significant deviations against targets and historical results.

It helps sales leaders and business analysts transform raw commercial data into actionable management insights.

The system focuses on answering three questions:

- What happened?
- Why did it happen?
- What should management do next?

---

## Business Problem

Sales teams frequently have access to large volumes of commercial data but limited time to transform that information into meaningful analysis.

Common challenges include:

- Manual sales reporting.
- Difficult comparison against targets.
- Inconsistent performance analysis.
- Limited visibility into sales trends.
- Difficulty identifying underperforming segments.
- Reports focused on numbers rather than actions.

---

## Business Objective

Produce a structured sales performance analysis that identifies key commercial trends, evaluates performance against targets and provides actionable recommendations for improving results.

---

## Typical Enterprise Scenario

A sales organization needs to evaluate monthly or quarterly performance across:

- Sales representatives.
- Regions.
- Products.
- Customers.
- Sales channels.
- Business units.

Management wants to understand which areas are performing well, which require attention and what actions could improve future results.

---

# Professional AI Workflow

## Step 1 — Define the Analysis Scope

Document:

- Reporting period.
- Business unit.
- Sales organization.
- Products or services.
- Geographic scope.
- Sales channels.
- Target audience.

---

## Step 2 — Prepare Sales Data

Provide:

- Actual sales.
- Sales targets.
- Previous-period sales.
- Historical sales.
- Customer information.
- Product information.
- Sales representative information.
- Geographic information.

Validate data completeness before analysis.

---

## Step 3 — Calculate Performance

Analyze:

- Actual vs Target.
- Current vs Previous Period.
- Year-over-Year performance.
- Growth rate.
- Achievement percentage.
- Contribution by segment.

---

## Step 4 — Segment Performance

Evaluate performance by:

- Region.
- Product.
- Sales representative.
- Customer.
- Channel.
- Business unit.

Identify high-performing and underperforming segments.

---

## Step 5 — Identify Significant Variances

Highlight:

- Largest positive variances.
- Largest negative variances.
- Significant growth.
- Significant decline.
- Unexpected movements.
- Persistent performance gaps.

---

## Step 6 — Analyze Potential Drivers

Evaluate available information for:

- Customer demand.
- Pricing.
- Product mix.
- Sales volume.
- Market conditions.
- Sales capacity.
- Seasonal patterns.
- Customer concentration.

Clearly distinguish confirmed drivers from hypotheses.

---

## Step 7 — Management Recommendations

Define actions related to:

- Underperforming segments.
- High-performing opportunities.
- Sales resource allocation.
- Product strategy.
- Customer strategy.
- Sales pipeline.
- Pricing.
- Forecasting.

---

## Step 8 — Executive Sales Summary

Generate:

- Executive Summary.
- Sales Performance Dashboard.
- Target Achievement.
- Growth Analysis.
- Segment Performance.
- Key Drivers.
- Risks.
- Opportunities.
- Recommended Actions.

---

# Professional AI Prompt

You are a Senior Sales Performance Analyst specializing in commercial analytics and executive reporting.

Analyze the supplied sales information and produce an executive-ready sales performance report.

Include:

- Executive Summary.
- Sales Performance Overview.
- Actual vs Target.
- Period-over-Period Comparison.
- Growth Analysis.
- Regional Performance.
- Product Performance.
- Customer Performance.
- Sales Representative Performance.
- Significant Variances.
- Performance Drivers.
- Risks.
- Opportunities.
- Recommended Actions.

Follow these rules:

1. Do not invent sales data.
2. Validate calculations before presenting conclusions.
3. Clearly distinguish facts from hypotheses.
4. Identify missing information.
5. Prioritize material commercial movements.
6. Explain the business meaning of significant results.
7. Use tables where they improve decision-making.

---

# Required Input Information

Collect:

- Reporting period.
- Sales actuals.
- Sales targets.
- Historical sales.
- Product data.
- Customer data.
- Sales representative data.
- Regional data.
- Channel information.
- Known commercial drivers.

---

# Expected Deliverables

Generate:

- Executive Sales Report.
- Sales Performance Dashboard.
- Target Achievement Analysis.
- Growth Analysis.
- Segment Performance Analysis.
- Variance Analysis.
- Opportunity Analysis.
- Risk Summary.
- Sales Action Plan.

---

# Validation Checklist

Verify:

- Reporting period is correct.
- Sales data is complete.
- Targets are correctly identified.
- Achievement percentages are accurate.
- Growth calculations are correct.
- Comparisons use compatible periods.
- Segments are correctly classified.
- Significant variances are identified.
- Business explanations are supported.
- Recommendations are actionable.

---

# Common Mistakes

Avoid:

- Focusing only on total sales.
- Ignoring target achievement.
- Comparing incompatible periods.
- Treating temporary fluctuations as trends.
- Creating unsupported explanations.
- Ignoring customer concentration.
- Providing recommendations without identifying the underlying performance issue.

---

# Best Practices

- Analyze both absolute and percentage changes.
- Compare actual performance with targets.
- Review multiple historical periods.
- Segment performance by meaningful business dimensions.
- Identify concentration risks.
- Connect sales metrics with business drivers.
- Highlight both risks and opportunities.
- Use consistent reporting periods.

---

# Business Value

Organizations benefit from:

- Faster sales reporting.
- Better commercial visibility.
- Earlier identification of performance gaps.
- Improved sales resource allocation.
- Better forecasting discussions.
- More actionable management reporting.

---

# Estimated Time Savings

Illustrative productivity improvement:

**2 to 5 hours per sales performance analysis**, depending on data volume and reporting complexity.

Actual savings depend on data preparation, validation and organizational reporting requirements.

---

# Expert Recommendations

Sales analysis should move beyond the question:

> How much did we sell?

A stronger analysis answers:

> How did we perform against expectations?

> Where did performance change?

> What appears to be driving the change?

> Where is the greatest opportunity?

> What should management do next?

The most valuable sales report converts commercial data into decisions rather than simply presenting sales numbers.

---

# Budget Variance Analysis System

## Executive Summary

The Budget Variance Analysis System provides a structured methodology for comparing actual financial performance against approved budgets, identifying material deviations and translating financial variances into actionable management insights.

It helps finance teams and business managers understand where performance differs from expectations, why those differences may have occurred and where corrective action may be required.

---

## Business Problem

Budget monitoring often relies on manually comparing financial figures without sufficiently explaining the underlying business drivers.

Common challenges include:

- Manual budget comparisons.
- Time-consuming variance calculations.
- Difficulty identifying material deviations.
- Limited visibility into cost drivers.
- Inconsistent management commentary.
- Delayed corrective action.
- Excessive focus on numbers without business interpretation.

---

## Business Objective

Produce a structured Budget Variance Analysis that identifies significant deviations between actual and planned performance, explains supported business drivers and provides actionable recommendations for management.

---

## Typical Enterprise Scenario

A business unit has completed its monthly reporting cycle.

Management needs to compare:

- Actual expenses.
- Approved budget.
- Forecast.
- Previous-period performance.

Leadership wants to understand which categories are materially above or below budget and whether corrective action is required.

---

# Professional AI Workflow

## Step 1 — Define the Analysis Scope

Document:

- Reporting period.
- Business unit.
- Cost center.
- Budget version.
- Currency.
- Analysis audience.
- Materiality threshold.

---

## Step 2 — Prepare Financial Data

Provide:

- Approved budget.
- Actual results.
- Forecast.
- Previous-period results.
- Relevant financial categories.
- Operational drivers.

Validate the data before performing the analysis.

---

## Step 3 — Calculate Variances

Calculate:

- Absolute variance.
- Percentage variance.
- Actual vs Budget.
- Actual vs Forecast.
- Current vs Previous Period.

Use consistent formulas and reporting periods.

---

## Step 4 — Identify Material Variances

Prioritize:

- Significant unfavorable variances.
- Significant favorable variances.
- Recurring deviations.
- Unexpected movements.
- Categories approaching tolerance thresholds.

Do not treat every variance as equally important.

---

## Step 5 — Analyze Variance Drivers

Evaluate available evidence for:

- Volume changes.
- Price changes.
- Headcount changes.
- Timing differences.
- One-time expenses.
- Supplier changes.
- Operational changes.
- Business demand.

Clearly distinguish confirmed causes from hypotheses.

---

## Step 6 — Assess Business Impact

For every material variance explain:

- Financial impact.
- Operational impact.
- Forecast impact.
- Potential future impact.
- Management relevance.

---

## Step 7 — Develop Corrective Actions

Recommend:

- Cost-control actions.
- Forecast adjustments.
- Resource reallocation.
- Budget revisions.
- Operational improvements.
- Additional investigation.

Assign owners where sufficient information is available.

---

## Step 8 — Prepare Executive Summary

Generate:

- Executive Summary.
- Budget Performance Overview.
- Material Variances.
- Variance Drivers.
- Financial Risks.
- Corrective Actions.
- Management Decisions Required.

---

# Professional AI Prompt

You are a Senior Financial Planning and Analysis professional specializing in budget management and management reporting.

Analyze the supplied budget and actual financial information.

Produce an executive-ready Budget Variance Analysis including:

- Executive Summary.
- Budget vs Actual.
- Budget vs Forecast.
- Period Comparison.
- Material Variances.
- Favorable Variances.
- Unfavorable Variances.
- Variance Drivers.
- Financial Impact.
- Risks.
- Corrective Actions.
- Management Recommendations.
- Decisions Required.

Follow these rules:

1. Do not invent financial values.
2. Verify variance calculations.
3. Clearly distinguish favorable and unfavorable variances.
4. Identify the materiality threshold when provided.
5. Distinguish confirmed causes from hypotheses.
6. Identify missing information.
7. Prioritize financially significant movements.
8. Use tables where they improve clarity.

---

# Required Input Information

Collect:

- Reporting period.
- Approved budget.
- Actual results.
- Forecast.
- Previous-period results.
- Cost categories.
- Cost centers.
- Materiality threshold.
- Known operational drivers.
- Management priorities.

---

# Expected Deliverables

Generate:

- Budget Variance Report.
- Executive Summary.
- Variance Dashboard.
- Material Variance Analysis.
- Financial Risk Summary.
- Corrective Action Plan.
- Management Recommendation List.

---

# Validation Checklist

Verify:

- Reporting period is correct.
- Budget version is identified.
- Actual values are validated.
- Variance calculations are accurate.
- Favorable and unfavorable movements are correctly classified.
- Material variances are prioritized.
- Explanations are supported by available evidence.
- Forecast implications are identified.
- Recommendations are actionable.
- No financial information has been fabricated.

---

# Common Mistakes

Avoid:

- Treating every variance as material.
- Ignoring favorable variances.
- Mixing budget and forecast comparisons.
- Using inconsistent reporting periods.
- Presenting unsupported explanations.
- Ignoring recurring deviations.
- Recommending corrective actions without understanding the driver.

---

# Best Practices

- Establish materiality thresholds.
- Analyze absolute and percentage variances.
- Separate recurring and one-time effects.
- Compare actuals against both budget and forecast.
- Investigate material deviations.
- Connect financial variances with operational drivers.
- Track corrective actions over subsequent reporting cycles.

---

# Business Value

Organizations benefit from:

- Faster budget analysis.
- Better financial visibility.
- Earlier identification of cost risks.
- More consistent management reporting.
- Improved financial accountability.
- Better resource allocation.
- Faster corrective action.

---

# Estimated Time Savings

Illustrative productivity improvement:

**2 to 4 hours per monthly budget analysis**, depending on the number of cost categories and reporting complexity.

Actual savings depend on data preparation, validation and organizational reporting requirements.

---

# Expert Recommendations

Budget variance analysis should not stop at identifying that actual results differ from the budget.

The real management value comes from understanding:

**What changed?**

**How significant is the change?**

**Why did it happen?**

**Is it temporary or recurring?**

**What should management do about it?**

A strong variance analysis transforms financial deviations into actionable business decisions.

---

# Operational Dashboard Creation System

## Executive Summary

The Operational Dashboard Creation System provides a structured methodology for transforming operational data into dashboards that help managers monitor performance, identify exceptions and make timely decisions.

The system focuses on selecting meaningful indicators, defining appropriate thresholds and translating operational metrics into actionable management information.

It is designed to accelerate dashboard planning and reporting while preserving the need for validated source data and professional interpretation.

---

## Business Problem

Operational teams often collect large amounts of information without converting it into useful management visibility.

Common challenges include:

- Excessive metrics.
- Manual reporting.
- Inconsistent dashboards.
- Poor KPI definitions.
- Limited visibility into exceptions.
- Delayed identification of operational problems.
- Dashboards that display data without supporting decisions.

---

## Business Objective

Design a structured operational dashboard that provides clear visibility into performance, highlights exceptions and enables managers to identify where action is required.

---

## Typical Enterprise Scenario

An operations team needs a dashboard to monitor a business service across multiple dimensions.

Available information includes:

- Transaction volumes.
- Processing times.
- Service levels.
- Error rates.
- Capacity.
- Backlog.
- Productivity.
- Customer-impact indicators.

Management needs a dashboard that quickly communicates whether operations are healthy and where intervention may be required.

---

# Professional AI Workflow

## Step 1 — Define the Dashboard Objective

Document:

- Business process.
- Dashboard audience.
- Reporting frequency.
- Operational objective.
- Decisions the dashboard should support.

---

## Step 2 — Identify Operational Dimensions

Determine the dimensions relevant to the process:

- Time.
- Business unit.
- Region.
- Product.
- Service.
- Channel.
- Team.
- Customer segment.

Only include dimensions that support meaningful analysis.

---

## Step 3 — Select Key Metrics

Identify relevant indicators such as:

- Volume.
- Processing time.
- Throughput.
- Error rate.
- Service level.
- Backlog.
- Capacity utilization.
- Productivity.
- Quality.

For each metric define:

- Name.
- Definition.
- Unit.
- Target.
- Threshold.
- Data source.
- Owner.

---

## Step 4 — Define Performance Thresholds

Classify performance into categories such as:

### Normal

Performance is within expected parameters.

### Attention

Performance is approaching a defined threshold.

### Critical

Performance has exceeded the acceptable limit and requires intervention.

Thresholds must be defined according to the organization's actual operational requirements.

---

## Step 5 — Design Dashboard Structure

Organize the dashboard into logical sections:

### Executive Overview

Show the most important operational indicators.

### Performance Trends

Display relevant historical movement.

### Exceptions

Highlight metrics requiring attention.

### Operational Detail

Provide supporting information for investigation.

### Actions

Display open actions and responsible owners when applicable.

---

## Step 6 — Analyze Operational Trends

Evaluate:

- Increasing trends.
- Decreasing trends.
- Recurring deviations.
- Seasonal patterns.
- Capacity constraints.
- Emerging risks.

Do not classify a trend without sufficient historical information.

---

## Step 7 — Define Management Actions

For significant exceptions identify:

- Issue.
- Business impact.
- Recommended action.
- Owner.
- Priority.
- Expected completion.

---

## Step 8 — Prepare Dashboard Specification

Generate:

- Dashboard objective.
- KPI catalogue.
- Metric definitions.
- Thresholds.
- Visual recommendations.
- Data sources.
- Refresh frequency.
- Ownership model.
- Exception management process.

---

# Professional AI Prompt

You are a Senior Business Intelligence and Operations Analyst specializing in executive and operational dashboards.

Analyze the supplied operational information and design a professional dashboard specification.

Include:

- Dashboard Objective.
- Target Audience.
- KPI Catalogue.
- Metric Definitions.
- Performance Targets.
- Thresholds.
- Trend Analysis.
- Exception Indicators.
- Recommended Visualizations.
- Data Sources.
- Refresh Frequency.
- Ownership.
- Management Actions.

Follow these rules:

1. Do not invent operational data.
2. Do not define thresholds without identifying them as proposed when business thresholds are unavailable.
3. Clearly identify missing information.
4. Prioritize metrics that support decisions.
5. Avoid unnecessary dashboard complexity.
6. Explain why each major KPI is relevant.
7. Use tables where appropriate.

---

# Required Input Information

Collect:

- Business process.
- Dashboard audience.
- Operational objectives.
- Available metrics.
- KPI definitions.
- Historical data.
- Targets.
- Thresholds.
- Data sources.
- Refresh requirements.
- Business owners.

---

# Expected Deliverables

Generate:

- Dashboard Specification.
- KPI Catalogue.
- Metric Dictionary.
- Threshold Matrix.
- Recommended Dashboard Layout.
- Exception Management Model.
- Management Action Plan.

---

# Validation Checklist

Verify:

- Dashboard objective is clear.
- Target audience is defined.
- KPIs support business objectives.
- Metric definitions are unambiguous.
- Data sources are identified.
- Targets are validated.
- Thresholds are documented.
- Trends are supported by historical data.
- Exceptions are clearly identified.
- Recommended actions are actionable.

---

# Common Mistakes

Avoid:

- Including every available metric.
- Creating dashboards without a defined audience.
- Using unclear KPI definitions.
- Creating arbitrary thresholds.
- Showing data without business interpretation.
- Ignoring historical trends.
- Mixing strategic and operational metrics without clear separation.

---

# Best Practices

- Start with decisions, then select metrics.
- Keep the primary dashboard concise.
- Use consistent KPI definitions.
- Establish thresholds with business owners.
- Highlight exceptions rather than displaying everything equally.
- Include historical context.
- Define data ownership.
- Establish a clear refresh frequency.
- Review dashboard usefulness periodically.

---

# Business Value

Organizations benefit from:

- Faster operational visibility.
- Earlier identification of performance problems.
- Better management decisions.
- Reduced manual reporting.
- More consistent KPI monitoring.
- Improved operational accountability.

---

# Estimated Time Savings

Illustrative productivity improvement:

**3 to 6 hours when designing or restructuring an operational dashboard**, depending on the number of KPIs, data sources and stakeholder requirements.

Actual savings depend on dashboard complexity and data availability.

---

# Expert Recommendations

A dashboard should not be designed around the question:

> What data do we have?

It should be designed around:

> What decisions do we need to make?

The strongest operational dashboards prioritize exceptions, trends and actions.

A successful dashboard allows a manager to quickly determine:

**What is happening?**

**Where is it happening?**

**Why does it matter?**

**What action is required?**

That is the difference between a data display and a management tool.

---

# OAuth Integration Documentation System

## Executive Summary


## Business Problem

Authentication and authorization integrations can be difficult to document consistently because they involve multiple components, configuration requirements and security considerations.

## Business Objective

Create comprehensive technical documentation for an OAuth integration covering architecture, configuration, authentication flows, security considerations, operational requirements and troubleshooting.

The OAuth Integration Documentation System provides a structured methodology for documenting enterprise authentication integrations based on OAuth 2.0 and OpenID Connect. It is intended to produce implementation-ready documentation that can be consumed by architects, developers, security teams, QA analysts, operations engineers and technical support.

Rather than documenting only configuration steps, this system captures business objectives, architecture decisions, authentication flows, operational considerations and support guidance, ensuring that the documentation remains useful throughout the entire lifecycle of the integration.

---

# Business Problem

Enterprise authentication projects often suffer from incomplete or inconsistent documentation.

Typical issues include:

- Missing authentication sequence diagrams.
- Poor explanation of token lifecycle.
- Missing security assumptions.
- Undefined responsibilities.
- Difficult maintenance.
- Slow onboarding of new team members.
- High dependency on individual knowledge.

These problems increase implementation time, operational risk and support costs.

---

# Business Objective

Produce enterprise-grade documentation that enables implementation, maintenance and operational support of OAuth integrations using a standardized structure.

The documentation should be understandable by both technical and functional stakeholders.

---

# Typical Enterprise Scenario

An organization is integrating an internal business application with an enterprise identity provider using OAuth 2.0 and OpenID Connect.

Multiple teams participate in the project:

- Enterprise Architecture
- Development
- Information Security
- QA
- Infrastructure
- Operations
- Technical Support
- Project Management

The documentation must serve as the single source of truth during implementation and future maintenance.

---

# Professional AI Workflow

## Step 1 — Understand the Business Context

Collect:

- Business objective
- Users involved
- Systems participating
- Security requirements
- Regulatory constraints
- Authentication requirements
- Authorization requirements

---

## Step 2 — Identify System Components

Document:

- Client Application
- Authorization Server
- Identity Provider
- Resource Server
- API Gateway (if applicable)
- Reverse Proxy (if applicable)

---

## Step 3 — Describe Authentication Flow

Include:

- Initial request
- User authentication
- Authorization request
- Authorization code exchange
- Access token generation
- Refresh token handling
- Session expiration
- Logout process

---

## Step 4 — Security Analysis

Document:

- Token lifetime
- Refresh strategy
- PKCE usage
- Scope definitions
- Client authentication
- Secret management
- Certificate requirements
- HTTPS requirements

---

## Step 5 — Operational Considerations

Describe:

- Monitoring
- Logging
- Metrics
- Troubleshooting
- Failure scenarios
- Recovery procedures
- Support responsibilities

---

# Professional AI Prompt

You are a Senior Enterprise Solution Architect specializing in authentication, authorization and enterprise security.

Create professional implementation documentation for an OAuth 2.0 and OpenID Connect integration.

The documentation must include:

- Executive Summary
- Business Objective
- Architecture Overview
- Functional Components
- Authentication Flow
- Authorization Flow
- Token Lifecycle
- Security Controls
- Configuration Parameters
- Operational Responsibilities
- Monitoring Strategy
- Logging Strategy
- Error Handling
- Failure Scenarios
- Support Procedures
- Deployment Considerations
- Risks
- Assumptions
- Recommendations
- Future Improvements

Use professional enterprise language suitable for architects, developers, support engineers and project managers.

---

# Required Input Information

Before generating documentation collect:

- Business objective
- Application description
- Identity Provider
- OAuth flow
- Redirect URIs
- Required scopes
- Client authentication method
- Token lifetime
- Security policies
- Operational contacts

---

# Expected Deliverables

The AI should generate:

- Complete technical documentation.
- Executive summary.
- Architecture overview.
- Authentication sequence.
- Authorization sequence.
- Configuration guide.
- Security considerations.
- Operational handbook.
- Troubleshooting guide.
- Implementation recommendations.

---

# Validation Checklist

Before approving the document verify:

- Business objective is clearly stated.
- Functional scope is complete.
- Authentication flow is accurate.
- Authorization flow is documented.
- Security assumptions are explicit.
- Configuration parameters are complete.
- Operational procedures are included.
- Risks are documented.
- Recommendations are actionable.

---

# Common Mistakes

Avoid:

- Documenting configuration without business context.
- Mixing authentication and authorization concepts.
- Omitting token lifecycle.
- Ignoring operational responsibilities.
- Forgetting monitoring requirements.
- Using inconsistent terminology.
- Leaving assumptions undocumented.

---

# Best Practices

- Write for multiple audiences.
- Separate business and technical sections.
- Explain why decisions were made.
- Document constraints.
- Include operational guidance.
- Keep terminology consistent.
- Maintain version history.
- Review documentation after every significant change.

---

# Business Value

Organizations benefit from:

- Faster implementations.
- Reduced onboarding time.
- Lower operational risk.
- Easier maintenance.
- Better collaboration between teams.
- Improved support quality.
- Higher documentation consistency.

---

# Estimated Time Savings

Estimated reduction in documentation effort:

**4 to 8 hours per integration**, depending on complexity.

---

# Expert Recommendations

Treat documentation as an operational asset rather than a project deliverable.

A well-structured document should enable a new engineer to understand the integration, support incidents and safely implement changes without relying on tribal knowledge.

Always document assumptions, operational ownership, security decisions and expected behaviours. Those sections become significantly more valuable over time than installation instructions alone.

---

# REST API Documentation System

## Executive Summary


## Business Problem

API teams frequently spend significant time documenting endpoints, parameters, authentication requirements, responses and operational considerations.

## Business Objective

Create structured REST API documentation that enables technical consumers to understand, integrate with and operate the API correctly.

The REST API Documentation System provides a standardized methodology for documenting enterprise REST services. It produces implementation-ready documentation that supports development, testing, integration, operations and long-term maintenance.

The objective is to ensure every API is understandable without relying on source code or institutional knowledge.

---

# Business Problem

REST APIs are frequently documented with only endpoint definitions, leaving critical implementation details undocumented.

Common consequences include:

- Slow integrations.
- Incorrect API consumption.
- Increased support requests.
- Difficult maintenance.
- Security misunderstandings.
- Inconsistent implementations.

---

# Business Objective

Produce complete enterprise API documentation that serves as the primary technical reference throughout the API lifecycle.

---

# Typical Enterprise Scenario

An organization exposes REST services for consumption by multiple internal and external applications.

Several teams consume the APIs simultaneously:

- Backend Development
- Frontend Development
- Integration Team
- QA
- Architecture
- Operations
- Technical Support

Documentation must remain accurate throughout future releases.

---

# Professional AI Workflow

## Step 1 — Understand the Business Capability

Document:

- Business process
- Functional objective
- Business owner
- Expected consumers
- Data ownership

---

## Step 2 — Define the API

Describe:

- Base URL
- Version
- Authentication method
- Media type
- Communication protocol

---

## Step 3 — Document Resources

For every endpoint include:

- URI
- HTTP Method
- Description
- Business purpose
- Request parameters
- Request body
- Response body
- Status codes

---

## Step 4 — Validation Rules

Document:

- Required fields
- Optional fields
- Data formats
- Maximum lengths
- Accepted values
- Validation rules

---

## Step 5 — Security

Document:

- Authentication
- Authorization
- Required scopes
- Rate limiting
- Sensitive information
- Encryption
- Audit requirements

---

## Step 6 — Error Handling

Describe:

- HTTP status codes
- Functional errors
- Technical errors
- Retry recommendations
- Client behaviour

---

## Step 7 — Operational Support

Include:

- Monitoring
- Logging
- Metrics
- Performance considerations
- Versioning strategy
- Backward compatibility

---

# Professional AI Prompt

You are a Senior Enterprise API Architect.

Generate enterprise-grade REST API documentation.

Include:

- Executive Summary
- Business Purpose
- API Overview
- Architecture
- Resources
- Endpoints
- Request Models
- Response Models
- Validation Rules
- Authentication
- Authorization
- Error Handling
- Operational Considerations
- Monitoring
- Logging
- Performance
- Versioning
- Security Recommendations
- Deployment Notes
- Future Improvements

Write using professional enterprise documentation standards.

---

# Required Input Information

Collect:

- Business capability
- Base URL
- API version
- Authentication mechanism
- Endpoints
- Request examples
- Response examples
- Error catalogue
- Consumers
- Dependencies

---

# Expected Deliverables

Generate:

- Executive documentation
- API specification
- Endpoint catalogue
- Request examples
- Response examples
- Security guidance
- Error catalogue
- Operational handbook

---

# Validation Checklist

Verify:

- Every endpoint documented.
- Parameters complete.
- Validation rules included.
- Authentication documented.
- Error catalogue complete.
- Examples provided.
- Operational guidance included.
- Version documented.

---

# Common Mistakes

Avoid:

- Missing request examples.
- Missing response examples.
- Undocumented status codes.
- Missing validation rules.
- Ignoring versioning.
- Omitting security requirements.
- Mixing business and technical descriptions.

---

# Best Practices

- Document every endpoint.
- Include realistic payload examples.
- Explain business purpose before technical details.
- Keep terminology consistent.
- Maintain version history.
- Review documentation after every API change.

---

# Business Value

This system provides:

- Faster integrations.
- Reduced implementation errors.
- Lower support costs.
- Better developer experience.
- Consistent API governance.
- Improved maintainability.

---

# Estimated Time Savings

Estimated reduction:

**5 to 10 hours per API implementation.**

---

# Expert Recommendations

Document APIs as products, not merely technical interfaces.

Every endpoint should clearly explain:

- why it exists,
- who should use it,
- when it should be called,
- expected behaviour,
- limitations,
- operational considerations,
- security implications.

Documentation should remain valuable long after the original implementation team has changed.

---

# Enterprise Procedure Documentation System

## Executive Summary


## Business Problem

Enterprise procedures are often documented inconsistently, making operational execution and knowledge transfer more difficult.

## Business Objective

Create a clear, repeatable enterprise procedure that documents prerequisites, steps, controls, expected results, exceptions and escalation paths.

The Enterprise Procedure Documentation System provides a standardized framework for documenting operational procedures in a consistent, auditable and repeatable manner.

The objective is to eliminate ambiguity, reduce operational risk and ensure that business processes can be executed consistently regardless of who performs them.

---

# Business Problem

Organizations frequently rely on undocumented operational knowledge.

Common consequences include:

- Inconsistent execution.
- Long onboarding periods.
- Operational errors.
- Increased dependency on experienced personnel.
- Difficult audits.
- Poor process governance.

---

# Business Objective

Create professional operational procedures that standardize execution, improve knowledge transfer and reduce operational risk.

---

# Typical Enterprise Scenario

A business process is executed daily by multiple teams located in different regions.

Without standardized documentation, each team performs the activity differently, producing inconsistent results and increasing operational costs.

---

# Professional AI Workflow

## Step 1 — Define the Business Process

Document:

- Process name
- Business objective
- Process owner
- Stakeholders
- Trigger event
- Expected outcome

---

## Step 2 — Define Scope

Specify:

- Included activities
- Excluded activities
- Preconditions
- Assumptions
- Dependencies

---

## Step 3 — Identify Roles

Document:

- Responsible role
- Supporting roles
- Approval authority
- Escalation contacts

---

## Step 4 — Describe the Procedure

For each activity include:

- Step number
- Description
- Responsible role
- Required inputs
- Expected outputs
- Validation points

---

## Step 5 — Exception Handling

Document:

- Possible exceptions
- Decision criteria
- Escalation path
- Recovery actions

---

## Step 6 — Operational Controls

Include:

- Quality controls
- Mandatory validations
- Compliance requirements
- Audit evidence

---

## Step 7 — Continuous Improvement

Document:

- Review frequency
- Improvement opportunities
- Lessons learned
- Version history

---

# Professional AI Prompt

You are a Senior Business Process Consultant specializing in enterprise operational procedures.

Create professional operational documentation.

The procedure must include:

- Executive Summary
- Business Objective
- Scope
- Roles
- Responsibilities
- Preconditions
- Inputs
- Outputs
- Detailed Activities
- Decision Points
- Exception Handling
- Operational Controls
- Compliance Considerations
- Risks
- Metrics
- Improvement Opportunities
- Version Control

Write using enterprise documentation standards.

---

# Required Input Information

Collect:

- Process objective
- Business area
- Stakeholders
- Responsible roles
- Inputs
- Outputs
- Systems involved
- Business rules
- Compliance requirements

---

# Expected Deliverables

Generate:

- Standard Operating Procedure
- Process overview
- Activity sequence
- Responsibility matrix
- Validation checklist
- Exception catalogue
- Operational recommendations

---

# Validation Checklist

Verify:

- Objective defined.
- Scope documented.
- Roles assigned.
- Steps sequential.
- Decision points identified.
- Exceptions documented.
- Controls included.
- Outputs clearly defined.

---

# Common Mistakes

Avoid:

- Missing responsibilities.
- Undefined inputs.
- Ambiguous activities.
- Missing validation steps.
- Ignoring exceptions.
- Lack of version control.

---

# Best Practices

- Write one action per step.
- Use measurable language.
- Define ownership.
- Explain expected outputs.
- Review procedures regularly.
- Maintain revision history.

---

# Business Value

This system helps organizations:

- Standardize execution.
- Reduce operational errors.
- Improve compliance.
- Accelerate onboarding.
- Simplify audits.
- Preserve organizational knowledge.

---

# Estimated Time Savings

Estimated reduction:

**4 to 6 hours for every documented operational process.**

---

# Expert Recommendations

Document procedures so they can be executed successfully by someone with no previous exposure to the process.

If a step depends on assumptions that are only known by experienced personnel, document those assumptions explicitly.

Operational excellence depends on repeatability rather than individual expertise.

---

# Root Cause Analysis System

## Executive Summary


## Business Problem

Technical incidents can result in incomplete root cause documentation when evidence, timelines, contributing factors and corrective actions are not systematically organized.

## Business Objective

Create an evidence-based root cause analysis that explains the incident, establishes the causal chain and defines corrective and preventive actions.

The Root Cause Analysis System provides a structured methodology for investigating incidents, identifying their underlying causes and defining corrective actions that prevent recurrence.

Instead of focusing only on restoring service, this system emphasizes learning, continuous improvement and operational resilience.

---

# Business Problem

Many organizations resolve incidents without understanding why they occurred.

As a result:

- The same incidents happen repeatedly.
- Corrective actions are ineffective.
- Teams lose confidence in operational processes.
- Support costs increase.
- Service reliability decreases.

---

# Business Objective

Produce a structured Root Cause Analysis (RCA) that explains not only what happened, but also why it happened, how it was resolved and what actions are required to prevent recurrence.

---

# Typical Enterprise Scenario

A critical production incident affected business operations.

The incident has already been resolved.

Management requires a formal Root Cause Analysis document that explains:

- Timeline
- Impact
- Technical causes
- Organizational causes
- Recovery actions
- Preventive actions

---

# Professional AI Workflow

## Step 1 — Incident Overview

Document:

- Incident identifier
- Date and time
- Severity
- Business impact
- Duration
- Services affected

---

## Step 2 — Business Impact Assessment

Describe:

- Users affected
- Business processes interrupted
- Financial impact
- Operational impact
- Customer impact

---

## Step 3 — Timeline Reconstruction

Build a chronological timeline including:

- Detection
- Escalation
- Investigation
- Mitigation
- Recovery
- Service restoration
- Closure

---

## Step 4 — Technical Investigation

Document:

- Observed symptoms
- System behavior
- Evidence collected
- Logs reviewed
- Metrics analyzed
- Configuration changes
- Infrastructure conditions

---

## Step 5 — Root Cause Identification

Identify:

- Immediate cause
- Contributing factors
- Organizational factors
- Process weaknesses
- Technical weaknesses

Use techniques such as:

- Five Whys
- Cause-and-Effect Analysis
- Fault Tree Analysis (when applicable)

---

## Step 6 — Corrective Actions

Define:

- Immediate corrective actions
- Permanent corrective actions
- Process improvements
- Monitoring improvements
- Documentation updates

Assign:

- Owner
- Priority
- Target completion date

---

## Step 7 — Preventive Measures

Document:

- Preventive controls
- Automation opportunities
- Monitoring enhancements
- Operational improvements
- Training recommendations

---

# Professional AI Prompt

You are a Senior Site Reliability Engineer and Enterprise Incident Manager.

Prepare a professional Root Cause Analysis report for a production incident.

Include:

- Executive Summary
- Incident Overview
- Business Impact
- Timeline
- Technical Investigation
- Evidence
- Root Cause
- Contributing Factors
- Corrective Actions
- Preventive Actions
- Risks
- Lessons Learned
- Recommendations
- Follow-up Actions

Use objective, factual and evidence-based language.

Do not speculate.

Clearly distinguish facts, assumptions and recommendations.

---

# Required Input Information

Collect:

- Incident description
- Detection time
- Resolution time
- Affected systems
- Business impact
- Evidence
- Logs
- Metrics
- Configuration changes
- Recovery actions

---

# Expected Deliverables

Generate:

- Executive RCA Report
- Incident Timeline
- Root Cause Statement
- Corrective Action Plan
- Preventive Action Plan
- Lessons Learned
- Management Summary

---

# Validation Checklist

Verify:

- Timeline is complete.
- Evidence supports conclusions.
- Root cause identified.
- Contributing factors documented.
- Corrective actions assigned.
- Preventive actions measurable.
- Lessons learned documented.
- Recommendations actionable.

---

# Common Mistakes

Avoid:

- Blaming individuals.
- Confusing symptoms with root causes.
- Omitting evidence.
- Missing timeline details.
- Defining vague corrective actions.
- Closing the analysis without preventive measures.

---

# Best Practices

- Base conclusions on evidence.
- Keep the investigation objective.
- Document assumptions separately.
- Focus on process improvement.
- Assign ownership for every action.
- Review implementation of corrective actions.

---

# Business Value

This system enables organizations to:

- Reduce recurring incidents.
- Improve operational reliability.
- Strengthen governance.
- Increase service availability.
- Improve collaboration between technical and business teams.
- Build a culture of continuous improvement.

---

# Estimated Time Savings

Estimated reduction:

**5 to 8 hours per major incident investigation.**

---

# Expert Recommendations

A Root Cause Analysis is not complete when the incident is resolved.

It is complete only when:

- the true root cause has been demonstrated,
- corrective actions have owners,
- preventive measures have been implemented,
- and the organization has incorporated the lessons learned into its operational practices.

An effective RCA strengthens the organization long after the incident itself has been forgotten.

---

# Knowledge Transfer System

## Executive Summary


## Business Problem

Knowledge transfer becomes inefficient when critical technical, operational and business information is distributed across multiple people and documents.

## Business Objective

Create a structured knowledge-transfer package that captures the information required for another professional or team to understand and operate the solution.

The Knowledge Transfer System provides a structured framework for capturing, organizing and transferring technical and operational knowledge between teams, projects and support organizations.

Its objective is to reduce dependency on individuals, accelerate onboarding, preserve organizational knowledge and ensure business continuity.

Rather than producing meeting notes, this system creates reusable operational knowledge assets that remain valuable long after a project has been completed.

---

# Business Problem

Organizations frequently lose critical knowledge when experienced personnel change roles, leave the company or complete projects.

Common consequences include:

- Slow onboarding.
- Repeated mistakes.
- Longer incident resolution.
- Reduced operational efficiency.
- High dependency on specific individuals.
- Knowledge silos.
- Increased operational risk.

---

# Business Objective

Create a complete Knowledge Transfer Package that enables another team to operate, support and maintain a solution with minimal additional guidance.

---

# Typical Enterprise Scenario

A project implementation has reached production.

The implementation team must transfer operational responsibility to another team.

The receiving team requires complete documentation explaining:

- Business purpose.
- Functional behaviour.
- Technical architecture.
- Operational procedures.
- Support responsibilities.
- Common issues.
- Escalation paths.

---

# Professional AI Workflow

## Step 1 — Solution Overview

Document:

- Solution name
- Business objective
- Business capabilities
- Scope
- Stakeholders

---

## Step 2 — Functional Overview

Describe:

- Main business processes
- Functional modules
- Integrations
- External dependencies
- Data flow

---

## Step 3 — Technical Overview

Document:

- Architecture
- Components
- Services
- Interfaces
- Authentication
- Infrastructure
- Configuration

---

## Step 4 — Operational Responsibilities

Define:

- Daily activities
- Weekly activities
- Monthly activities
- Monitoring responsibilities
- Maintenance responsibilities
- Support responsibilities

---

## Step 5 — Support Model

Document:

- Support levels
- Escalation process
- Incident ownership
- Contact matrix
- Communication channels

---

## Step 6 — Common Operational Scenarios

Describe:

- Normal operation
- Known issues
- Recovery procedures
- Planned maintenance
- Emergency procedures

---

## Step 7 — Knowledge Validation

Verify that the receiving team can:

- Explain the solution.
- Execute operational tasks.
- Resolve common incidents.
- Escalate correctly.
- Maintain the solution safely.

---

# Professional AI Prompt

You are a Senior Enterprise Solution Architect preparing a complete Knowledge Transfer Package.

Generate professional documentation including:

- Executive Summary
- Business Context
- Functional Overview
- Technical Overview
- Architecture Summary
- Operational Responsibilities
- Support Model
- Monitoring Strategy
- Maintenance Activities
- Common Operational Procedures
- Incident Response
- Escalation Process
- Risks
- Recommendations
- Knowledge Validation Checklist
- Future Improvements

Write for operations engineers, support teams, project managers and technical leaders.

---

# Required Input Information

Collect:

- Solution description
- Business purpose
- Stakeholders
- Architecture overview
- Integrations
- Operational activities
- Monitoring tools
- Support responsibilities
- Escalation contacts
- Known issues

---

# Expected Deliverables

Generate:

- Knowledge Transfer Guide
- Functional Overview
- Technical Overview
- Operations Handbook
- Support Guide
- Escalation Matrix
- Maintenance Guide
- Executive Summary

---

# Validation Checklist

Verify:

- Business objective documented.
- Functional overview complete.
- Architecture explained.
- Operational tasks documented.
- Support responsibilities assigned.
- Escalation process defined.
- Maintenance activities included.
- Knowledge transfer objectives achieved.

---

# Common Mistakes

Avoid:

- Assuming previous knowledge.
- Omitting operational procedures.
- Missing ownership definitions.
- Incomplete architecture descriptions.
- Ignoring support responsibilities.
- Delivering documentation without validation.
- Failing to document known limitations.

---

# Best Practices

- Write for the receiving team.
- Separate functional and technical concepts.
- Use consistent terminology.
- Include operational examples.
- Validate documentation with future support teams.
- Update documentation after significant changes.

---

# Business Value

Organizations benefit from:

- Faster onboarding.
- Reduced operational dependency.
- Improved service continuity.
- Better collaboration between teams.
- Lower support costs.
- Increased documentation quality.
- Stronger operational governance.

---

# Estimated Time Savings

Estimated reduction:

**8 to 12 hours during every operational transition or project handover.**

---

# Expert Recommendations

Knowledge transfer is successful only when the receiving team can independently operate and support the solution without relying on the original implementation team.

Documentation should answer not only *how* a solution works, but also *why* it exists, *who* is responsible for each operational activity and *how* future changes should be managed.

Treat every Knowledge Transfer Package as a long-term operational asset that evolves together with the solution rather than as a document produced only at the end of a project.

---

# Production Incident Investigation System

## Executive Summary


## Business Problem

Production incidents require rapid organization of evidence, timelines, impact information and technical findings while minimizing unsupported assumptions.

## Business Objective

Create a structured production incident investigation that establishes the timeline, impact, evidence, hypotheses, findings, root cause and corrective actions.

The Production Incident Investigation System provides a structured methodology for investigating critical production incidents while minimizing service disruption and preserving evidence for post-incident analysis.

The objective is to enable technical teams to identify the true cause of an incident, restore service safely and generate actionable improvements that reduce the likelihood of recurrence.

---

# Business Problem

Production incidents frequently trigger unstructured investigations.

Common consequences include:

- Delayed service restoration.
- Inconsistent troubleshooting.
- Loss of critical evidence.
- Incorrect conclusions.
- Repeated incidents.
- Poor communication between teams.

---

# Business Objective

Provide a repeatable investigation framework that enables technical teams to restore service while preserving sufficient evidence to understand what happened and why.

---

# Typical Enterprise Scenario

A critical production application begins returning errors during business hours.

Multiple teams become involved simultaneously:

- Operations
- Infrastructure
- Application Support
- Database Administration
- Network Engineering
- Cybersecurity
- Business Owners

The investigation must remain structured despite operational pressure.

---

# Professional AI Workflow

## Step 1 — Incident Classification

Document:

- Incident ID
- Detection Time
- Severity
- Business Priority
- Affected Services
- Initial Symptoms

---

## Step 2 — Immediate Containment

Identify:

- Temporary mitigation
- Business continuity actions
- Rollback options
- Service isolation
- Communication actions

---

## Step 3 — Evidence Collection

Collect:

- Application logs
- Infrastructure logs
- Metrics
- Monitoring alerts
- Configuration changes
- Deployment history
- User reports

Do not modify evidence.

---

## Step 4 — Technical Investigation

Analyze:

- Timeline
- Recent deployments
- Infrastructure changes
- Authentication events
- Resource utilization
- Database activity
- External dependencies

---

## Step 5 — Hypothesis Validation

For each hypothesis document:

- Supporting evidence
- Contradicting evidence
- Confidence level
- Validation performed
- Conclusion

---

## Step 6 — Root Cause Confirmation

Document:

- Immediate Cause
- Root Cause
- Contributing Factors
- Organizational Factors
- Technical Factors

---

## Step 7 — Recovery Validation

Confirm:

- Services operational
- Monitoring normal
- Business validation completed
- No secondary impacts
- Incident closed safely

---

# Professional AI Prompt

You are a Senior Enterprise Incident Manager.

Investigate a production incident using a structured, evidence-based methodology.

Produce:

- Executive Summary
- Business Impact
- Technical Impact
- Timeline
- Investigation
- Evidence
- Root Cause
- Contributing Factors
- Corrective Actions
- Preventive Actions
- Lessons Learned
- Executive Recommendations

Never speculate.

Clearly distinguish facts from assumptions.

---

# Required Input Information

Collect:

- Incident description
- Detection time
- Affected services
- Business impact
- Infrastructure changes
- Application changes
- Logs
- Metrics
- Monitoring alerts
- Recovery actions

---

# Expected Deliverables

Generate:

- Incident Investigation Report
- Executive Summary
- Timeline
- Technical Analysis
- Evidence Catalogue
- Root Cause Statement
- Action Plan
- Lessons Learned

---

# Validation Checklist

Verify:

- Timeline complete.
- Evidence preserved.
- Business impact documented.
- Technical impact documented.
- Root cause validated.
- Corrective actions assigned.
- Preventive actions defined.
- Recovery confirmed.

---

# Common Mistakes

Avoid:

- Assuming the first symptom is the root cause.
- Changing systems before collecting evidence.
- Ignoring business impact.
- Closing the investigation prematurely.
- Missing cross-team communication.

---

# Best Practices

- Preserve evidence first.
- Maintain a chronological timeline.
- Validate every hypothesis.
- Separate facts from opinions.
- Record every decision.
- Keep stakeholders informed.

---

# Business Value

Organizations benefit from:

- Faster investigations.
- Better operational decisions.
- Reduced downtime.
- Higher service reliability.
- Improved collaboration.
- Stronger operational governance.

---

# Estimated Time Savings

Estimated reduction:

**4 to 7 hours per major production incident.**

---

# Expert Recommendations

Successful incident investigations are driven by evidence, not assumptions.

Every investigation should leave the organization with:

- better documentation,
- stronger monitoring,
- improved operational procedures,
- and a measurable reduction in future operational risk.

The quality of the investigation is measured not only by how quickly service was restored, but by how effectively the organization learns from the incident.

---

# Enterprise Log Analysis System

## Executive Summary


## Business Problem

Large volumes of application and infrastructure logs can make it difficult to identify the events that actually explain a production problem.

## Business Objective

Analyze supplied log information systematically to identify relevant events, correlations, anomalies, potential causes and recommended investigation paths.

The Enterprise Log Analysis System provides a structured methodology for analyzing application, infrastructure and integration logs to identify operational issues, performance degradation, security anomalies and application failures.

The objective is to transform raw log data into actionable operational intelligence.

---

# Business Problem

Enterprise platforms generate thousands or even millions of log entries every day.

Without a structured analysis process, teams experience:

- Slow troubleshooting.
- Missed anomalies.
- Poor incident diagnosis.
- Repeated failures.
- Long service outages.
- High operational costs.

---

# Business Objective

Create a repeatable log analysis process that rapidly identifies anomalies, correlates events and supports evidence-based technical decisions.

---

# Typical Enterprise Scenario

Users report intermittent failures in a business application.

Monitoring indicates increased response times.

Application logs, infrastructure logs and integration logs must be analyzed together to determine the source of the issue.

---

# Professional AI Workflow

## Step 1 — Define the Investigation Scope

Document:

- Incident reference
- Time window
- Systems involved
- Log sources
- Business impact
- Investigation objective

---

## Step 2 — Inventory Available Logs

Identify:

- Application logs
- Web server logs
- API gateway logs
- Authentication logs
- Database logs
- Infrastructure logs
- Container logs
- Operating system logs

---

## Step 3 — Initial Pattern Detection

Search for:

- ERROR
- WARN
- FATAL
- Exception
- Timeout
- Connection refused
- Authentication failures
- Resource exhaustion

Identify frequency and recurrence.

---

## Step 4 — Correlation Analysis

Correlate events using:

- Timestamp
- Transaction ID
- Correlation ID
- Session ID
- User identifier
- Request identifier

Reconstruct the execution path.

---

## Step 5 — Technical Assessment

Determine:

- Failure point
- First observable symptom
- Downstream impact
- Upstream dependency
- External dependency
- Recovery behavior

---

## Step 6 — Findings

Document:

- Confirmed observations
- Supporting evidence
- Rejected hypotheses
- Root cause indicators
- Remaining unknowns

---

## Step 7 — Recommendations

Provide:

- Immediate corrective actions
- Monitoring improvements
- Logging improvements
- Configuration recommendations
- Preventive actions

---

# Professional AI Prompt

You are a Senior Enterprise Support Engineer specializing in enterprise log analysis.

Analyze the supplied logs.

Produce:

- Executive Summary
- Timeline
- Event Correlation
- Error Classification
- Technical Findings
- Probable Root Cause
- Supporting Evidence
- Risk Assessment
- Recommendations
- Monitoring Improvements

Do not speculate.

Clearly identify which conclusions are supported by evidence.

---

# Required Input Information

Collect:

- Log files
- Time window
- Incident reference
- System architecture
- Correlation identifiers
- Monitoring alerts
- Deployment history
- Configuration changes

---

# Expected Deliverables

Generate:

- Executive Investigation Summary
- Error Catalogue
- Correlated Timeline
- Technical Findings
- Evidence Summary
- Recommendations
- Preventive Actions

---

# Validation Checklist

Verify:

- Time window validated.
- Correlation IDs identified.
- Errors classified.
- Timeline reconstructed.
- Evidence documented.
- Findings supported.
- Recommendations actionable.

---

# Common Mistakes

Avoid:

- Reviewing only one log source.
- Ignoring timestamps.
- Mixing unrelated events.
- Assuming the first error is the root cause.
- Ignoring warning messages.
- Omitting infrastructure logs.

---

# Best Practices

- Correlate multiple log sources.
- Preserve original evidence.
- Normalize timestamps.
- Investigate recurring patterns.
- Record every assumption separately.
- Validate conclusions with monitoring data.

---

# Business Value

Organizations benefit from:

- Faster diagnosis.
- Reduced downtime.
- Better monitoring.
- Improved operational visibility.
- Stronger troubleshooting processes.
- Lower support costs.

---

# Estimated Time Savings

Estimated reduction:

**3 to 6 hours per complex log investigation.**

---

# Expert Recommendations

Logs should never be analyzed in isolation.

Combine application logs, infrastructure metrics, deployment history and monitoring events to build a complete operational picture.

The objective is not simply to locate an error message, but to understand the complete sequence of events that produced the failure and identify the earliest observable indicator of the underlying problem.

---

# Performance Bottleneck Investigation System

## Executive Summary


## Business Problem

Performance problems often involve multiple components and require structured analysis to distinguish symptoms from the underlying bottleneck.

## Business Objective

Create a structured performance investigation that identifies bottlenecks, supporting evidence, affected components, potential causes and recommended remediation actions.

The Performance Bottleneck Investigation System provides a structured methodology for identifying, analyzing and resolving performance issues affecting enterprise applications, APIs, databases and distributed systems.

Rather than focusing solely on infrastructure utilization, this system evaluates the complete execution path to determine where performance degradation originates and how it affects business operations.

---

# Business Problem

Enterprise applications frequently experience performance degradation caused by multiple contributing factors rather than a single technical issue.

Typical consequences include:

- Slow response times.
- User dissatisfaction.
- Reduced productivity.
- Missed service level objectives.
- Increased infrastructure costs.
- Difficulty identifying the actual bottleneck.

---

# Business Objective

Identify the primary performance bottleneck, quantify its business impact and define corrective actions that improve overall system performance.

---

# Typical Enterprise Scenario

Users report that a business application becomes progressively slower during peak operating hours.

Monitoring shows increased response times, but CPU utilization remains within acceptable limits.

The investigation must determine whether the bottleneck originates in:

- Application logic
- Database
- Infrastructure
- Network
- External integrations
- Authentication services
- Resource contention

---

# Professional AI Workflow

## Step 1 — Define Investigation Scope

Document:

- Business service
- Affected users
- Time window
- Service Level Objective
- Business impact
- Severity

---

## Step 2 — Collect Performance Evidence

Gather:

- Response times
- CPU utilization
- Memory utilization
- Disk latency
- Network latency
- Database statistics
- Queue lengths
- Thread utilization
- Garbage collection metrics
- Application traces

---

## Step 3 — Analyze the Application Layer

Review:

- Long-running requests
- Slow transactions
- Thread contention
- Connection pools
- Application exceptions
- Cache behavior

---

## Step 4 — Analyze the Database Layer

Evaluate:

- Slow queries
- Missing indexes
- Lock contention
- Deadlocks
- Execution plans
- Connection usage

---

## Step 5 — Analyze Infrastructure

Verify:

- Virtual machines
- Containers
- Storage performance
- Network bandwidth
- DNS resolution
- Load balancers
- Reverse proxies

---

## Step 6 — Correlate Findings

Identify:

- Primary bottleneck
- Secondary bottlenecks
- Contributing factors
- Operational risks
- Business impact

---

## Step 7 — Optimization Plan

Recommend:

- Configuration improvements
- Infrastructure changes
- Query optimization
- Application improvements
- Monitoring enhancements
- Capacity planning

---

# Professional AI Prompt

You are a Senior Enterprise Performance Engineer.

Analyze the available evidence and identify the primary performance bottleneck.

Produce:

- Executive Summary
- Performance Assessment
- Technical Findings
- Resource Analysis
- Bottleneck Identification
- Evidence
- Risks
- Optimization Recommendations
- Capacity Recommendations
- Monitoring Improvements

Support every conclusion with available evidence.

---

# Required Input Information

Collect:

- Performance metrics
- Response times
- Infrastructure metrics
- Database metrics
- Application traces
- Monitoring dashboards
- Recent deployments
- Configuration changes
- User reports

---

# Expected Deliverables

Generate:

- Executive Performance Report
- Bottleneck Analysis
- Evidence Summary
- Optimization Roadmap
- Capacity Assessment
- Monitoring Recommendations

---

# Validation Checklist

Verify:

- Business impact quantified.
- Metrics analyzed.
- Evidence documented.
- Primary bottleneck identified.
- Secondary bottlenecks documented.
- Recommendations prioritized.
- Capacity risks evaluated.

---

# Common Mistakes

Avoid:

- Investigating only infrastructure.
- Ignoring database performance.
- Assuming CPU is always the bottleneck.
- Analyzing isolated metrics.
- Drawing conclusions without evidence.
- Ignoring workload patterns.

---

# Best Practices

- Analyze the complete request lifecycle.
- Correlate metrics across all layers.
- Compare current behavior with historical baselines.
- Validate improvements after implementation.
- Continuously review capacity trends.
- Automate performance monitoring whenever possible.

---

# Business Value

Organizations benefit from:

- Faster applications.
- Improved user experience.
- Better resource utilization.
- Reduced infrastructure costs.
- Increased operational stability.
- Higher service availability.

---

# Estimated Time Savings

Estimated reduction:

**5 to 8 hours per performance investigation.**

---

# Expert Recommendations

Performance optimization should focus on the constraint that limits the overall system, not necessarily the component with the highest resource utilization.

Every optimization initiative should establish measurable performance objectives before implementation and validate results afterward using the same metrics collected during the initial investigation.

Treat performance engineering as an ongoing operational discipline rather than a reactive troubleshooting activity.

---

# Critical Error Diagnosis System

## Executive Summary


## Business Problem

Critical technical errors can create significant operational impact when teams lack a consistent process for gathering evidence, isolating causes and defining remediation.

## Business Objective

Create a structured critical-error diagnosis that organizes symptoms, evidence, hypotheses, root causes, remediation and preventive actions.

The Critical Error Diagnosis System provides a structured methodology for diagnosing severe application failures that affect business continuity, service availability or operational stability.

Its purpose is to accelerate diagnosis, minimize business impact and produce evidence-based conclusions that support corrective and preventive actions.

Unlike traditional troubleshooting guides, this system emphasizes systematic analysis rather than isolated technical observations.

---

# Business Problem

Critical application failures frequently generate operational pressure that leads to rushed decisions and incomplete investigations.

Common consequences include:

- Extended outages.
- Incorrect fixes.
- Repeated incidents.
- Increased operational risk.
- Poor communication.
- Loss of business confidence.

---

# Business Objective

Diagnose critical enterprise application failures using a repeatable investigation framework that identifies technical causes, business impact and recovery priorities.

---

# Typical Enterprise Scenario

A production application suddenly becomes unavailable during business hours.

Users report failed transactions and monitoring detects a significant increase in application errors.

Multiple technical teams must collaborate to restore service while preserving evidence for later analysis.

---

# Professional AI Workflow

## Step 1 — Incident Registration

Document:

- Incident identifier
- Detection time
- Severity
- Affected business service
- Business owner
- Current operational status

---

## Step 2 — Impact Assessment

Determine:

- Users affected
- Business processes interrupted
- Financial impact
- Regulatory impact
- Customer impact
- Service Level Agreement implications

---

## Step 3 — Error Classification

Classify the failure:

- Functional
- Technical
- Infrastructure
- Database
- Integration
- Security
- Capacity
- Configuration
- External dependency

---

## Step 4 — Evidence Collection

Collect:

- Application logs
- Infrastructure metrics
- Database evidence
- Monitoring alerts
- Configuration snapshots
- Deployment history
- Authentication events
- Network diagnostics

Preserve evidence before making changes.

---

## Step 5 — Diagnostic Analysis

Evaluate:

- Error frequency
- Failure sequence
- Trigger conditions
- System dependencies
- Infrastructure health
- Resource utilization
- External integrations

---

## Step 6 — Cause Verification

Validate:

- Primary cause
- Secondary causes
- Contributing conditions
- Reproducibility
- Supporting evidence

Reject unsupported assumptions.

---

## Step 7 — Recovery Strategy

Document:

- Immediate actions
- Temporary mitigation
- Permanent solution
- Verification steps
- Business validation
- Monitoring after recovery

---

# Professional AI Prompt

You are a Senior Enterprise Support Architect responsible for diagnosing critical production failures.

Analyze the available technical and business information.

Produce:

- Executive Summary
- Incident Assessment
- Business Impact
- Technical Findings
- Evidence Analysis
- Error Classification
- Diagnostic Timeline
- Root Cause
- Corrective Actions
- Preventive Recommendations
- Executive Conclusions

Support every conclusion with observable evidence.

---

# Required Input Information

Collect:

- Incident description
- Business impact
- Error messages
- Application logs
- Infrastructure metrics
- Monitoring alerts
- Configuration changes
- Recent deployments
- Recovery actions
- System architecture

---

# Expected Deliverables

Generate:

- Executive Diagnosis Report
- Technical Assessment
- Evidence Catalogue
- Root Cause Statement
- Recovery Plan
- Improvement Recommendations
- Operational Summary

---

# Validation Checklist

Verify:

- Incident documented.
- Business impact quantified.
- Technical evidence preserved.
- Error classification completed.
- Root cause validated.
- Recovery verified.
- Recommendations prioritized.
- Executive summary completed.

---

# Common Mistakes

Avoid:

- Jumping directly to conclusions.
- Ignoring business impact.
- Discarding evidence after recovery.
- Assuming correlation implies causation.
- Applying changes without documentation.
- Closing the incident without verification.

---

# Best Practices

- Preserve evidence before intervention.
- Build a complete investigation timeline.
- Validate hypotheses with measurable data.
- Separate facts from interpretations.
- Keep stakeholders informed.
- Document every operational decision.

---

# Business Value

Organizations benefit from:

- Faster diagnosis.
- Better decision making.
- Reduced downtime.
- Improved operational governance.
- Higher service reliability.
- Better cross-functional collaboration.

---

# Estimated Time Savings

Estimated reduction:

**4 to 8 hours for every critical production incident.**

---

# Expert Recommendations

The objective of a diagnosis is not simply to restore service.

A successful diagnosis should leave the organization with:

- a verified technical explanation,
- documented operational knowledge,
- measurable corrective actions,
- improved monitoring,
- and reduced probability of recurrence.

Every critical incident should strengthen the operational maturity of the organization.

---

# Disaster Recovery Planning System

## Executive Summary


## Business Problem

Organizations require documented recovery procedures to reduce operational uncertainty when critical systems become unavailable.

## Business Objective

Create a structured disaster-recovery plan covering recovery objectives, dependencies, procedures, responsibilities, validation and escalation.

The Disaster Recovery Planning System provides a structured framework for preparing, validating and maintaining recovery strategies for enterprise technology services following critical operational disruptions.

Its objective is to minimize business interruption, reduce recovery time and ensure that essential business services can be restored safely after a disaster.

The system combines business continuity principles with technical recovery planning to produce actionable recovery documentation.

---

# Business Problem

Many organizations maintain backup procedures but lack comprehensive disaster recovery plans.

Common consequences include:

- Extended service outages.
- Unclear recovery responsibilities.
- Inconsistent recovery procedures.
- Recovery activities performed in the wrong sequence.
- Communication failures.
- Business continuity risks.
- Regulatory non-compliance.

---

# Business Objective

Develop a comprehensive Disaster Recovery Plan that enables technical and business teams to restore critical services within agreed recovery objectives while minimizing operational and financial impact.

---

# Typical Enterprise Scenario

A major infrastructure failure affects multiple production services.

Business operations are interrupted.

Recovery teams must restore services using predefined recovery procedures while coordinating technical activities, executive communications and business validation.

---

# Professional AI Workflow

## Step 1 — Business Impact Analysis

Document:

- Critical business services
- Business priority
- Recovery objectives
- Maximum acceptable downtime
- Operational dependencies
- Regulatory requirements

---

## Step 2 — Recovery Scope

Identify:

- Applications
- Infrastructure
- Databases
- Storage
- Network
- Authentication services
- External integrations
- Supporting services

---

## Step 3 — Recovery Objectives

Define:

- Recovery Time Objective (RTO)
- Recovery Point Objective (RPO)
- Recovery priority
- Service dependencies
- Recovery sequence

---

## Step 4 — Recovery Procedures

Document:

- Initial assessment
- Infrastructure recovery
- Database recovery
- Application recovery
- Integration validation
- Security verification
- Functional validation
- Business validation

---

## Step 5 — Roles and Responsibilities

Assign:

- Disaster Recovery Manager
- Infrastructure Team
- Database Team
- Application Support
- Security Team
- Business Owners
- Executive Sponsors

---

## Step 6 — Communication Plan

Document:

- Incident notifications
- Executive updates
- Business communications
- Customer communications
- Regulatory notifications
- Recovery status reporting

---

## Step 7 — Recovery Validation

Verify:

- Service availability
- Data integrity
- Functional validation
- Security validation
- Business approval
- Operational monitoring

---

## Step 8 — Continuous Improvement

Document:

- Lessons learned
- Recovery metrics
- Recovery testing results
- Improvement actions
- Documentation updates

---

# Professional AI Prompt

You are a Senior Enterprise Business Continuity and Disaster Recovery Consultant.

Prepare a complete Disaster Recovery Plan.

Include:

- Executive Summary
- Business Impact Analysis
- Recovery Objectives
- Recovery Strategy
- Technical Recovery Procedures
- Operational Recovery Procedures
- Communication Plan
- Roles and Responsibilities
- Validation Activities
- Risk Assessment
- Recovery Testing Strategy
- Lessons Learned
- Improvement Opportunities

Produce documentation suitable for enterprise operations.

---

# Required Input Information

Collect:

- Business services
- System architecture
- Critical applications
- Recovery objectives
- Infrastructure inventory
- Backup strategy
- Recovery environment
- Operational contacts
- Compliance requirements
- Existing recovery procedures

---

# Expected Deliverables

Generate:

- Disaster Recovery Plan
- Business Impact Assessment
- Recovery Sequence
- Communication Plan
- Responsibility Matrix
- Validation Checklist
- Recovery Testing Plan
- Executive Summary

---

# Validation Checklist

Verify:

- Critical services identified.
- Recovery objectives approved.
- Dependencies documented.
- Recovery sequence validated.
- Responsibilities assigned.
- Communication plan completed.
- Testing strategy documented.
- Recovery plan reviewed.

---

# Common Mistakes

Avoid:

- Assuming backups guarantee recovery.
- Ignoring business priorities.
- Missing dependency mapping.
- Undefined ownership.
- Recovery procedures that have never been tested.
- Outdated infrastructure documentation.
- Lack of executive communication planning.

---

# Best Practices

- Test recovery procedures regularly.
- Review recovery objectives annually.
- Maintain updated infrastructure inventories.
- Validate backup restoration procedures.
- Include business stakeholders in recovery exercises.
- Record lessons learned after every recovery exercise.

---

# Business Value

Organizations benefit from:

- Reduced operational downtime.
- Faster service restoration.
- Improved business resilience.
- Better regulatory compliance.
- Lower operational risk.
- Increased executive confidence.
- Stronger business continuity capabilities.

---

# Estimated Time Savings

Estimated reduction:

**8 to 16 hours during major recovery events through standardized planning and execution.**

---

# Expert Recommendations

Disaster Recovery planning should never be treated as a document created only for audit purposes.

A recovery plan is successful only when technical teams can execute it confidently under pressure and business stakeholders can verify that critical services have been restored according to agreed recovery objectives.

Recovery planning should be reviewed, tested and continuously improved as systems, infrastructure and business priorities evolve.

---

# Project Kickoff Planning System

## Executive Summary


## Business Problem

Project teams often begin initiatives with incomplete alignment around objectives, scope, stakeholders, responsibilities and expected outcomes.

## Business Objective

Create a structured project kickoff package that establishes the project context, objectives, scope, stakeholders, responsibilities, risks and immediate actions.

The Project Kickoff Planning System provides a structured framework for planning, organizing and launching enterprise projects with clearly defined objectives, governance, responsibilities and execution strategies.

Its purpose is to ensure that every project begins with a shared understanding of scope, expectations, risks, success criteria and stakeholder responsibilities.

A well-executed kickoff significantly reduces misunderstandings, accelerates execution and improves project governance throughout the project lifecycle.

---

# Business Problem

Many enterprise projects begin without complete alignment between business and technical teams.

Typical consequences include:

- Unclear objectives.
- Scope misunderstandings.
- Conflicting priorities.
- Undefined responsibilities.
- Delayed decisions.
- Increased project risk.
- Budget overruns.

---

# Business Objective

Develop a comprehensive Project Kickoff Package that aligns all stakeholders before execution begins.

The kickoff documentation should establish governance, communication, scope and success criteria that guide the project from initiation through delivery.

---

# Typical Enterprise Scenario

An organization is starting a strategic initiative involving multiple business units, technical teams and external vendors.

Before execution begins, leadership requires a structured kickoff package defining:

- Project objectives.
- Business value.
- Scope.
- Governance.
- Timeline.
- Risks.
- Roles.
- Communication model.

---

# Professional AI Workflow

## Step 1 — Project Overview

Document:

- Project name
- Business sponsor
- Project manager
- Business owner
- Strategic objective
- Expected business value

---

## Step 2 — Define Business Objectives

Describe:

- Business problem
- Desired future state
- Success criteria
- Expected measurable outcomes
- Strategic alignment

---

## Step 3 — Scope Definition

Document:

Included:

- Deliverables
- Functional scope
- Technical scope
- Integrations
- Interfaces

Excluded:

- Future phases
- Deferred functionality
- Out-of-scope activities

---

## Step 4 — Stakeholder Analysis

Identify:

- Executive Sponsor
- Business Owner
- Project Manager
- Technical Lead
- Functional Lead
- Operations
- Security
- Quality Assurance
- Infrastructure

Document responsibilities for each role.

---

## Step 5 — Governance Model

Define:

- Decision authority
- Steering committee
- Escalation path
- Change approval process
- Reporting cadence

---

## Step 6 — Project Timeline

Identify:

- Major milestones
- Deliverables
- Dependencies
- Critical path
- Decision gates

---

## Step 7 — Initial Risk Assessment

Document:

- Business risks
- Technical risks
- Organizational risks
- Resource risks
- Schedule risks

Assign:

- Probability
- Impact
- Mitigation strategy
- Risk owner

---

## Step 8 — Communication Plan

Define:

- Executive reporting
- Project meetings
- Status reports
- Escalation meetings
- Decision meetings
- Stakeholder communications

---

# Professional AI Prompt

You are a Senior Enterprise Project Manager.

Prepare a complete Project Kickoff Package.

Include:

- Executive Summary
- Business Objectives
- Project Scope
- Deliverables
- Governance Model
- Stakeholder Matrix
- Timeline
- Initial Risk Register
- Communication Plan
- Assumptions
- Constraints
- Success Criteria
- Recommendations

Use professional project management standards suitable for enterprise environments.

---

# Required Input Information

Collect:

- Business objective
- Project sponsor
- Project manager
- Stakeholders
- Scope
- Timeline
- Budget constraints
- Dependencies
- Known risks
- Success criteria

---

# Expected Deliverables

Generate:

- Project Charter
- Kickoff Presentation Content
- Stakeholder Matrix
- Communication Plan
- Initial Risk Register
- Governance Model
- Executive Summary

---

# Validation Checklist

Verify:

- Objectives approved.
- Scope defined.
- Stakeholders identified.
- Governance documented.
- Timeline validated.
- Risks documented.
- Success criteria measurable.
- Communication plan complete.

---

# Common Mistakes

Avoid:

- Starting without executive alignment.
- Undefined project scope.
- Missing stakeholder ownership.
- Unrealistic timelines.
- Ignoring project risks.
- Weak governance structure.
- Poor communication planning.

---

# Best Practices

- Align business and technical objectives before execution.
- Clearly document project boundaries.
- Define decision-making authority early.
- Review assumptions with stakeholders.
- Establish measurable success criteria.
- Schedule recurring governance reviews.

---

# Business Value

Organizations benefit from:

- Better project alignment.
- Faster decision making.
- Reduced project risk.
- Improved stakeholder engagement.
- Higher delivery predictability.
- Stronger governance.

---

# Estimated Time Savings

Estimated reduction:

**6 to 10 hours during project initiation while significantly improving planning quality.**

---

# Expert Recommendations

Successful projects are rarely the result of exceptional execution alone.

They begin with exceptional planning.

A comprehensive kickoff package creates alignment before work starts, reducing uncertainty, preventing scope confusion and establishing governance that supports successful delivery throughout the project lifecycle.

---

# Weekly Project Status Reporting System

## Executive Summary


## Business Problem

Project status reporting frequently consumes significant time while still failing to communicate the information executives actually need.

## Business Objective

Produce a concise weekly project status report that communicates progress, health, risks, issues, decisions and upcoming priorities.

The Weekly Project Status Reporting System provides a standardized methodology for preparing executive project status reports that communicate progress, risks, decisions and upcoming priorities with clarity and consistency.

The objective is to reduce the time spent preparing reports while increasing the quality of information available for project governance and executive decision-making.

---

# Business Problem

Project status reports are often inconsistent, overly technical or incomplete.

Typical consequences include:

- Executive uncertainty.
- Delayed decisions.
- Inconsistent reporting.
- Poor visibility into project health.
- Increased governance effort.
- Misaligned stakeholder expectations.

---

# Business Objective

Produce concise, accurate and executive-ready weekly project reports that enable leadership to understand project health, make informed decisions and proactively manage risks.

---

# Typical Enterprise Scenario

A strategic enterprise project involves multiple workstreams, technical teams and business stakeholders.

Every week, project leadership must present an executive summary covering:

- Overall health.
- Progress against milestones.
- Key achievements.
- Risks.
- Issues.
- Decisions required.
- Activities planned for the following week.

---

# Professional AI Workflow

## Step 1 — Collect Project Information

Gather:

- Reporting period
- Current milestone
- Planned progress
- Actual progress
- Completed deliverables
- Outstanding activities

---

## Step 2 — Assess Project Health

Evaluate:

- Scope
- Schedule
- Budget
- Resources
- Quality
- Risks
- Stakeholder engagement

Assign a status indicator for each area.

---

## Step 3 — Summarize Achievements

Document:

- Completed deliverables
- Key milestones achieved
- Business value delivered
- Significant accomplishments

---

## Step 4 — Identify Risks and Issues

Separate:

### Risks

Potential events that could affect the project.

### Issues

Events currently affecting execution.

For each item define:

- Description
- Impact
- Owner
- Mitigation
- Expected resolution

---

## Step 5 — Executive Decisions

Document:

- Decisions required
- Responsible decision makers
- Required date
- Business impact

---

## Step 6 — Next Week Plan

Include:

- Planned activities
- Upcoming milestones
- Deliverables
- Dependencies
- Expected outcomes

---

## Step 7 — Executive Summary

Produce a one-page summary covering:

- Overall project health
- Major achievements
- Significant concerns
- Executive priorities
- Recommendations

---

# Professional AI Prompt

You are a Senior Enterprise Project Manager preparing a Weekly Executive Status Report.

Generate:

- Executive Summary
- Overall Project Health
- Progress Summary
- Milestone Status
- Completed Activities
- Planned Activities
- Risks
- Issues
- Decisions Required
- Budget Status
- Resource Status
- Recommendations
- Executive Actions

Use concise executive language suitable for senior leadership.

---

# Required Input Information

Collect:

- Reporting period
- Current milestone
- Project schedule
- Completed activities
- Planned activities
- Open risks
- Open issues
- Budget status
- Resource availability
- Executive decisions pending

---

# Expected Deliverables

Generate:

- Executive Status Report
- Project Dashboard Summary
- Risk Summary
- Issue Register
- Milestone Overview
- Executive Action List
- Weekly Management Summary

---

# Validation Checklist

Verify:

- Reporting period defined.
- Milestones updated.
- Progress quantified.
- Risks documented.
- Issues assigned.
- Decisions identified.
- Executive summary completed.
- Recommendations actionable.

---

# Common Mistakes

Avoid:

- Reporting activities instead of outcomes.
- Hiding project risks.
- Overloading executives with technical detail.
- Missing ownership.
- Omitting key decisions.
- Using inconsistent reporting formats.

---

# Best Practices

- Focus on business outcomes.
- Quantify progress whenever possible.
- Highlight only material risks.
- Clearly distinguish risks from issues.
- Use consistent reporting periods.
- Keep executive summaries concise.

---

# Business Value

Organizations benefit from:

- Better executive visibility.
- Faster governance decisions.
- Improved stakeholder confidence.
- Earlier risk identification.
- Consistent reporting standards.
- Increased project transparency.

---

# Estimated Time Savings

Estimated reduction:

**3 to 5 hours every reporting cycle while improving executive communication quality.**

---

# Expert Recommendations

A weekly status report should enable an executive to understand the project's condition in less than five minutes.

Every section should answer one of three questions:

- What changed?
- Why does it matter?
- What action is required?

If a report cannot answer those questions clearly, it is unlikely to support effective project governance.

---

# Project Risk Assessment System

## Executive Summary


## Business Problem

Project teams need a consistent way to identify, evaluate, prioritize and communicate risks before they become material issues.

## Business Objective

Create a structured project risk assessment that identifies relevant risks, evaluates their potential impact and likelihood, and defines appropriate mitigation actions.

The Project Risk Assessment System provides a structured methodology for identifying, evaluating, prioritizing and managing project risks throughout the project lifecycle.

Rather than reacting after problems occur, this system promotes proactive risk management that supports informed decision-making, protects project objectives and improves delivery predictability.

---

# Business Problem

Projects frequently identify risks too late, after they have already affected scope, schedule, budget or quality.

Typical consequences include:

- Schedule delays.
- Budget overruns.
- Resource shortages.
- Poor stakeholder confidence.
- Increased operational disruption.
- Reduced delivery quality.

---

# Business Objective

Develop a structured Project Risk Assessment that enables project teams and executives to understand potential threats, evaluate their impact and implement appropriate mitigation strategies before risks materialize.

---

# Typical Enterprise Scenario

A strategic technology initiative involves multiple departments, external vendors and several system integrations.

Project leadership requires a complete risk assessment before major implementation activities begin.

The assessment must support governance meetings, executive reporting and project decision-making.

---

# Professional AI Workflow

## Step 1 — Define Assessment Scope

Document:

- Project name
- Business objective
- Assessment date
- Project phase
- Assessment participants
- Business owner

---

## Step 2 — Identify Risks

Identify risks related to:

- Business processes
- Technical implementation
- Infrastructure
- Security
- Compliance
- Resources
- Budget
- Schedule
- Vendors
- Organizational change

---

## Step 3 — Risk Analysis

Evaluate each risk according to:

- Description
- Cause
- Potential consequence
- Probability
- Impact
- Exposure level

Classify each risk as:

- Low
- Medium
- High
- Critical

---

## Step 4 — Mitigation Strategy

For every identified risk define:

- Preventive actions
- Contingency actions
- Risk owner
- Target completion date
- Required resources

---

## Step 5 — Residual Risk Assessment

Evaluate:

- Remaining probability
- Remaining impact
- Acceptance criteria
- Escalation requirements

---

## Step 6 — Monitoring Strategy

Document:

- Monitoring frequency
- Early warning indicators
- Reporting cadence
- Governance meetings
- Escalation thresholds

---

## Step 7 — Executive Recommendations

Summarize:

- Highest priority risks
- Immediate actions
- Executive decisions required
- Recommended governance actions

---

# Professional AI Prompt

You are a Senior Enterprise Project Risk Manager.

Prepare a complete Project Risk Assessment.

Include:

- Executive Summary
- Project Context
- Risk Register
- Risk Classification
- Probability Assessment
- Impact Assessment
- Exposure Matrix
- Mitigation Strategy
- Contingency Plans
- Residual Risk
- Monitoring Plan
- Executive Recommendations

Write using professional enterprise risk management standards.

---

# Required Input Information

Collect:

- Project objective
- Scope
- Timeline
- Budget
- Stakeholders
- Technical architecture
- External dependencies
- Vendor information
- Known assumptions
- Project constraints

---

# Expected Deliverables

Generate:

- Executive Risk Report
- Risk Register
- Risk Matrix
- Mitigation Plan
- Contingency Plan
- Executive Dashboard
- Governance Recommendations

---

# Validation Checklist

Verify:

- Risks identified.
- Causes documented.
- Probability evaluated.
- Impact evaluated.
- Mitigation defined.
- Ownership assigned.
- Monitoring established.
- Executive recommendations completed.

---

# Common Mistakes

Avoid:

- Identifying risks without mitigation.
- Confusing risks with issues.
- Assigning no ownership.
- Ignoring organizational risks.
- Underestimating vendor dependencies.
- Failing to review risks periodically.

---

# Best Practices

- Review risks throughout the project lifecycle.
- Update probability and impact regularly.
- Assign a single owner for every risk.
- Escalate critical risks immediately.
- Validate mitigation effectiveness.
- Integrate risk management into governance meetings.

---

# Business Value

Organizations benefit from:

- Better project predictability.
- Earlier identification of threats.
- Improved executive decision-making.
- Reduced project disruption.
- Stronger governance.
- Greater stakeholder confidence.

---

# Estimated Time Savings

Estimated reduction:

**4 to 6 hours during every formal project risk assessment while improving decision quality.**

---

# Expert Recommendations

Risk management should become part of everyday project management rather than a document prepared only for governance reviews.

The most valuable risk assessments are those that lead to preventive action before project objectives are affected.

A successful project is not one without risks, but one in which risks are continuously identified, evaluated and managed before they become issues.

---

# Stakeholder Communication System

## Executive Summary


## Business Problem

Project communication can become inconsistent when different stakeholders receive different levels of information, timing and messaging.

## Business Objective

Create a structured stakeholder communication approach that defines audiences, messages, channels, frequency, ownership and required actions.

The Stakeholder Communication System provides a structured methodology for planning, preparing and delivering consistent project communications to executives, business leaders, project teams and operational stakeholders.

Its objective is to ensure that every stakeholder receives the right information, at the right level of detail, through the appropriate communication channel and at the appropriate time.

Effective communication reduces uncertainty, accelerates decision-making and strengthens confidence throughout the project lifecycle.

---

# Business Problem

Projects frequently fail because communication is inconsistent rather than because of technical problems.

Typical consequences include:

- Misaligned expectations.
- Delayed executive decisions.
- Conflicting priorities.
- Duplicate work.
- Stakeholder dissatisfaction.
- Increased project risk.
- Poor organizational adoption.

---

# Business Objective

Develop a communication framework that provides timely, accurate and audience-appropriate information throughout the entire project lifecycle.

---

# Typical Enterprise Scenario

A strategic implementation involves executives, business owners, technical teams, vendors and operational support.

Each stakeholder group requires different information, different levels of technical detail and different reporting frequencies.

The project manager must maintain consistent communication while minimizing administrative effort.

---

# Professional AI Workflow

## Step 1 — Identify Stakeholders

Document:

- Executive Sponsors
- Business Owners
- Project Managers
- Technical Leaders
- Development Teams
- Operations
- Support Teams
- External Partners
- Regulatory Stakeholders

---

## Step 2 — Stakeholder Analysis

For every stakeholder determine:

- Responsibilities
- Influence
- Interest
- Decision authority
- Information needs
- Preferred communication style

---

## Step 3 — Communication Matrix

Define:

- Audience
- Purpose
- Communication channel
- Frequency
- Owner
- Expected outcome

Examples:

- Executive Steering Committee
- Weekly Status Meeting
- Technical Review
- Risk Review
- Change Approval
- Operational Handover

---

## Step 4 — Executive Communication

Prepare concise summaries including:

- Current project health
- Key achievements
- Major risks
- Critical issues
- Decisions required
- Recommended actions

---

## Step 5 — Technical Communication

Provide:

- Technical progress
- Integration status
- Testing updates
- Infrastructure readiness
- Operational readiness
- Technical risks

---

## Step 6 — Business Communication

Explain:

- Business value delivered
- Upcoming changes
- User impact
- Training activities
- Operational readiness
- Business milestones

---

## Step 7 — Escalation Strategy

Define:

- Escalation criteria
- Escalation authority
- Response expectations
- Decision timelines
- Executive notifications

---

# Professional AI Prompt

You are a Senior Enterprise Project Manager responsible for stakeholder communications.

Prepare a complete Stakeholder Communication Plan.

Include:

- Executive Summary
- Stakeholder Analysis
- Communication Objectives
- Communication Matrix
- Executive Communications
- Business Communications
- Technical Communications
- Escalation Process
- Governance Meetings
- Reporting Schedule
- Risks
- Recommendations

Use concise executive language suitable for enterprise governance.

---

# Required Input Information

Collect:

- Project objectives
- Stakeholder list
- Organizational structure
- Governance model
- Reporting requirements
- Meeting schedule
- Executive priorities
- Business milestones
- Known risks
- Communication constraints

---

# Expected Deliverables

Generate:

- Stakeholder Register
- Communication Matrix
- Executive Communication Plan
- Meeting Calendar
- Reporting Schedule
- Escalation Matrix
- Governance Summary

---

# Validation Checklist

Verify:

- Stakeholders identified.
- Communication objectives defined.
- Communication channels documented.
- Reporting frequency established.
- Escalation process documented.
- Meeting cadence defined.
- Executive reporting included.
- Ownership assigned.

---

# Common Mistakes

Avoid:

- Sending identical information to every audience.
- Overloading executives with technical detail.
- Communicating only when problems occur.
- Missing communication ownership.
- Ignoring stakeholder expectations.
- Delayed escalation.

---

# Best Practices

- Adapt communication to the audience.
- Maintain consistent reporting formats.
- Communicate risks early.
- Confirm understanding after major communications.
- Keep executive reports concise.
- Document important decisions.

---

# Business Value

Organizations benefit from:

- Better executive engagement.
- Faster decisions.
- Improved project transparency.
- Higher stakeholder satisfaction.
- Reduced communication gaps.
- Stronger governance.

---

# Estimated Time Savings

Estimated reduction:

**3 to 5 hours per week through standardized communication planning and reusable reporting structures.**

---

# Expert Recommendations

Project communication should enable informed decision-making rather than simply distribute information.

Every communication should clearly answer four questions:

- What changed?
- Why does it matter?
- What action is required?
- Who is responsible?

Consistent communication builds trust, improves governance and significantly increases the probability of successful project delivery.

---

# Lessons Learned Documentation System

## Executive Summary


## Business Problem

Organizations often complete projects without systematically capturing lessons that could improve future initiatives.

## Business Objective

Create a structured lessons-learned analysis that captures what worked, what did not, why it happened and what should change in future projects.

The Lessons Learned Documentation System provides a structured methodology for capturing, validating and reusing knowledge generated throughout the execution of enterprise projects.

Its purpose is to transform project experience into organizational knowledge that continuously improves future initiatives, delivery quality and operational maturity.

Lessons learned should not be viewed as project closure activities, but as strategic assets that reduce recurring mistakes and strengthen organizational capabilities.

---

# Business Problem

Many organizations complete projects without formally documenting what worked, what failed and why.

Common consequences include:

- Repeated mistakes.
- Loss of valuable knowledge.
- Continuous process inefficiencies.
- Weak organizational learning.
- Reduced project maturity.
- Increased delivery risk.
- Higher implementation costs.

---

# Business Objective

Produce a comprehensive Lessons Learned Report that captures successful practices, identified risks, improvement opportunities and recommendations for future projects.

The objective is to institutionalize knowledge rather than preserve individual experience.

---

# Typical Enterprise Scenario

A large enterprise implementation has reached completion.

The project involved multiple business units, technical teams and operational stakeholders.

Leadership requests a formal Lessons Learned Workshop followed by a documented report that can be used to improve governance, delivery methodology and future implementations.

---

# Professional AI Workflow

## Step 1 — Project Overview

Document:

- Project name
- Business objective
- Project duration
- Scope
- Business sponsor
- Project manager
- Delivery approach

---

## Step 2 — Identify Successes

Document:

- Successful practices
- Key achievements
- Effective decisions
- High-performing processes
- Positive stakeholder feedback

Explain why these practices contributed to project success.

---

## Step 3 — Identify Challenges

Analyze:

- Schedule deviations
- Scope changes
- Resource limitations
- Communication issues
- Technical challenges
- Operational constraints
- Governance weaknesses

Describe both technical and organizational causes.

---

## Step 4 — Root Cause Review

For every significant challenge identify:

- Primary cause
- Contributing factors
- Business impact
- Technical impact
- Resolution adopted
- Alternative approaches

---

## Step 5 — Recommendations

Provide recommendations for:

- Future projects
- Governance improvements
- Communication
- Planning
- Technical architecture
- Operational readiness
- Documentation quality
- Risk management

---

## Step 6 — Organizational Knowledge

Identify knowledge that should become organizational standards.

Examples:

- Standard templates
- Technical standards
- Governance improvements
- Communication practices
- Operational procedures

---

## Step 7 — Continuous Improvement Plan

Define:

- Improvement initiatives
- Responsible owners
- Priority
- Expected benefits
- Review schedule

---

# Professional AI Prompt

You are a Senior Enterprise Project Management Consultant facilitating a Lessons Learned Workshop.

Generate a complete Lessons Learned Report.

Include:

- Executive Summary
- Project Overview
- Successes
- Challenges
- Root Cause Analysis
- Organizational Learning
- Improvement Opportunities
- Recommendations
- Action Plan
- Governance Improvements
- Executive Conclusions

Produce objective, evidence-based documentation suitable for executive review.

---

# Required Input Information

Collect:

- Project objectives
- Final deliverables
- Timeline
- Stakeholder feedback
- Risks encountered
- Issues resolved
- Project metrics
- Team observations
- Business outcomes
- Customer feedback

---

# Expected Deliverables

Generate:

- Lessons Learned Report
- Executive Summary
- Success Catalogue
- Challenge Register
- Improvement Plan
- Organizational Knowledge Register
- Executive Recommendations

---

# Validation Checklist

Verify:

- Project objectives reviewed.
- Successes documented.
- Challenges analyzed.
- Root causes identified.
- Recommendations actionable.
- Organizational learning captured.
- Improvement plan defined.
- Executive summary completed.

---

# Common Mistakes

Avoid:

- Assigning personal blame.
- Documenting only failures.
- Ignoring successful practices.
- Producing vague recommendations.
- Failing to define ownership.
- Treating lessons learned as project closure paperwork.

---

# Best Practices

- Encourage honest participation.
- Focus on process improvement.
- Support conclusions with evidence.
- Balance successes and improvement opportunities.
- Share lessons across the organization.
- Review lessons before starting similar projects.

---

# Business Value

Organizations benefit from:

- Stronger project governance.
- Improved delivery quality.
- Faster future implementations.
- Better organizational learning.
- Reduced operational risk.
- Higher project maturity.
- Continuous process improvement.

---

# Estimated Time Savings

Estimated reduction:

**6 to 10 hours during future project planning by reusing documented organizational knowledge and avoiding previously identified issues.**

---

# Expert Recommendations

The value of a project is not measured solely by its deliverables, but also by the knowledge it leaves behind.

Every completed project should increase the organization's capability to deliver the next initiative more efficiently, with lower risk and higher quality.

Treat Lessons Learned as a permanent organizational asset that should continuously evolve and be consulted before every new strategic initiative.

---

# Executive Decision Memo System

## Executive Summary


## Business Problem

Executives and managers frequently need to make decisions using incomplete, fragmented or time-sensitive information.

Common challenges include:

- Large amounts of information with limited decision time.
- Difficulty comparing alternatives consistently.
- Recommendations buried inside lengthy documents.
- Risks and assumptions that are not clearly identified.
- Inconsistent decision documentation.
- Lack of a repeatable structure for executive decisions.

## Business Objective

Create a concise, evidence-based decision memo that clearly explains the situation, evaluates available alternatives, identifies risks and presents a recommended course of action for management consideration.

The Executive Decision Memo System provides a structured methodology for preparing executive decision documents that enable leadership teams to evaluate strategic options quickly and make informed decisions based on business evidence.

The objective is to replace lengthy reports with concise, decision-oriented documentation that clearly explains the problem, available options, associated risks and recommended course of action.

---

# Business Problem

Executive decisions are frequently delayed because information is:

- Incomplete.
- Inconsistent.
- Excessively technical.
- Poorly organized.
- Missing financial impact.
- Missing risk analysis.

Decision makers spend valuable time searching for information instead of evaluating alternatives.

---

# Business Objective

Develop concise Executive Decision Memos that enable senior leadership to understand a business situation, compare alternatives and approve an informed course of action within a short review period.

---

# Typical Enterprise Scenario

A project requires executive approval to proceed with a strategic initiative involving operational changes, technology investment and organizational resources.

Leadership requests a document summarizing:

- Business problem.
- Strategic objectives.
- Available alternatives.
- Risks.
- Financial considerations.
- Recommended decision.

---

# Professional AI Workflow

## Step 1 — Executive Context

Document:

- Decision title
- Business sponsor
- Decision owner
- Decision deadline
- Strategic objective
- Business priority

---

## Step 2 — Business Situation

Describe:

- Current situation
- Business drivers
- Existing limitations
- Operational challenges
- Strategic opportunities

---

## Step 3 — Decision Alternatives

For each alternative document:

- Description
- Advantages
- Disadvantages
- Estimated cost
- Business impact
- Technical complexity
- Risks

---

## Step 4 — Comparative Analysis

Compare alternatives using:

- Cost
- Time
- Risk
- Operational impact
- Strategic alignment
- Long-term sustainability

---

## Step 5 — Risk Assessment

Identify:

- Strategic risks
- Operational risks
- Financial risks
- Compliance risks
- Implementation risks

Document mitigation strategies.

---

## Step 6 — Recommendation

Provide:

- Recommended option
- Business justification
- Expected benefits
- Success metrics
- Assumptions
- Dependencies

---

## Step 7 — Executive Approval

Document:

- Decision required
- Approver
- Approval deadline
- Expected implementation date

---

# Professional AI Prompt

You are a Senior Strategy Consultant preparing an Executive Decision Memo.

Generate:

- Executive Summary
- Business Context
- Current Situation
- Strategic Objectives
- Alternatives Analysis
- Comparative Matrix
- Risk Assessment
- Financial Considerations
- Recommendation
- Success Metrics
- Executive Decision
- Next Steps

Write for executive leadership using concise business language.

---

# Required Input Information

Collect:

- Business objective
- Strategic initiative
- Alternatives
- Estimated costs
- Business risks
- Timeline
- Stakeholders
- Expected benefits
- Constraints
- Executive concerns

---

# Expected Deliverables

Generate:

- Executive Decision Memo
- Comparative Analysis
- Risk Summary
- Recommendation
- Executive Brief
- Decision Matrix
- Implementation Overview

---

# Validation Checklist

Verify:

- Business objective defined.
- Alternatives evaluated.
- Risks documented.
- Financial considerations included.
- Recommendation justified.
- Success metrics defined.
- Executive decision clearly requested.
- Next steps documented.

---

# Common Mistakes

Avoid:

- Presenting only one alternative.
- Providing excessive technical detail.
- Ignoring business risks.
- Omitting financial implications.
- Making recommendations without evidence.
- Leaving decision ownership undefined.

---

# Best Practices

- Limit the memo to essential information.
- Use measurable business outcomes.
- Compare alternatives objectively.
- Clearly identify assumptions.
- Highlight strategic impact.
- Keep recommendations actionable.

---

# Business Value

Organizations benefit from:

- Faster executive decisions.
- Better strategic alignment.
- Increased governance quality.
- Improved transparency.
- Better investment prioritization.
- More consistent decision documentation.

---

# Estimated Time Savings

Estimated reduction:

**2 to 4 hours for every executive decision package while improving decision quality and governance.**

---

# Expert Recommendations

An Executive Decision Memo should never attempt to answer every possible question.

Its purpose is to enable informed decisions by presenting the minimum amount of information necessary to evaluate the available alternatives with confidence.

Strong decision documents reduce uncertainty, improve governance and accelerate organizational execution.

---

# Executive Presentation Builder System

## Executive Summary


## Business Problem

Professional presentations often require significant effort to organize information, determine the right narrative and adapt technical or operational content for an executive audience.

Common challenges include:

- Starting presentations from a blank page.
- Excessive information density.
- Weak narrative structure.
- Inconsistent slide hierarchy.
- Difficulty translating complex information into executive language.
- Spending excessive time refining presentation content.

## Business Objective

Create a structured presentation narrative that communicates the business situation, key findings, recommendations and required actions clearly to the intended audience.

The Executive Presentation Builder System provides a structured methodology for creating executive-level presentations that communicate business value, strategic direction and decision-making information with clarity and consistency.

The objective is to transform large volumes of business information into concise, visually structured presentations that support executive discussions, steering committees and board-level reviews.

Rather than focusing on slide design alone, this system emphasizes narrative structure, business impact and executive decision support.

---

# Business Problem

Many presentations contain excessive information but fail to communicate the message executives actually need.

Typical consequences include:

- Long meetings.
- Unclear decisions.
- Poor executive engagement.
- Confusing visual structure.
- Missing business outcomes.
- Inconsistent messaging.

---

# Business Objective

Produce executive presentations that clearly explain business context, current status, strategic recommendations and expected outcomes while minimizing unnecessary detail.

---

# Typical Enterprise Scenario

A project manager must present the status of a strategic initiative to executive leadership.

The presentation should summarize several months of work into a concise deck covering:

- Current status.
- Business value delivered.
- Risks.
- Financial impact.
- Upcoming milestones.
- Executive decisions required.

The audience consists of senior leaders with limited time available.

---

# Professional AI Workflow

## Step 1 — Define Presentation Objective

Document:

- Presentation title
- Business objective
- Audience
- Meeting type
- Presenter
- Desired executive outcome

---

## Step 2 — Build Executive Narrative

Structure the presentation using:

- Current Situation
- Business Challenge
- Analysis
- Proposed Solution
- Business Benefits
- Risks
- Recommendation
- Decision Required

Ensure each section supports the next logically.

---

## Step 3 — Organize Slide Structure

Suggested slide sequence:

1. Title
2. Executive Summary
3. Business Context
4. Current Situation
5. Key Findings
6. Strategic Analysis
7. Options
8. Recommendation
9. Risks
10. Implementation Roadmap
11. Decisions Required
12. Questions

---

## Step 4 — Define Visual Content

For each slide determine:

- Objective
- Key message
- Suggested chart
- Suggested diagram
- Supporting metrics
- Executive takeaway

Avoid unnecessary decoration.

---

## Step 5 — Executive Messaging

Ensure every slide answers:

- Why does this matter?
- What changed?
- What decision is required?
- What business value is expected?

---

## Step 6 — Speaker Notes

Prepare concise presenter guidance including:

- Opening message
- Key talking points
- Anticipated executive questions
- Recommended responses
- Transition to next slide

---

## Step 7 — Presentation Review

Validate:

- Logical flow
- Consistent terminology
- Executive readability
- Data accuracy
- Visual simplicity
- Decision readiness

---

# Professional AI Prompt

You are a Senior Strategy Consultant preparing an executive presentation.

Generate:

- Executive Summary
- Slide Outline
- Slide Objectives
- Key Messages
- Suggested Visuals
- Executive Talking Points
- Risks
- Recommendations
- Decisions Required
- Closing Summary

Use concise executive language appropriate for board meetings and steering committees.

---

# Required Input Information

Collect:

- Presentation objective
- Audience
- Business problem
- Strategic initiative
- Project status
- Financial information
- KPIs
- Risks
- Recommendations
- Decisions required

---

# Expected Deliverables

Generate:

- Executive Presentation Outline
- Slide-by-Slide Content
- Executive Summary
- Talking Points
- Suggested Charts
- Meeting Notes
- Decision Summary

---

# Validation Checklist

Verify:

- Audience identified.
- Business objective clear.
- Narrative logical.
- Slides concise.
- Data validated.
- Risks documented.
- Recommendations actionable.
- Decisions explicitly requested.

---

# Common Mistakes

Avoid:

- Filling slides with paragraphs.
- Presenting raw data without interpretation.
- Mixing operational detail with executive messaging.
- Omitting business impact.
- Using inconsistent terminology.
- Asking for decisions without supporting analysis.

---

# Best Practices

- One primary message per slide.
- Use visuals to support—not replace—the narrative.
- Focus on outcomes rather than activities.
- Keep executive summaries brief.
- Highlight business value before technical detail.
- Finish with a clear decision request.

---

# Business Value

Organizations benefit from:

- Faster executive alignment.
- Better strategic communication.
- Higher-quality governance meetings.
- Improved decision-making.
- Greater stakeholder engagement.
- More consistent executive messaging.

---

# Estimated Time Savings

Estimated reduction:

**3 to 6 hours for every executive presentation while significantly improving communication quality.**

---

# Expert Recommendations

Executive presentations should tell a business story rather than display information.

Every slide should contribute to a single objective:

Move the audience toward an informed decision.

If a slide does not support that objective, it should be simplified, moved to an appendix or removed entirely.

---

# Weekly Leadership Summary System

## Executive Summary


## Business Problem

Professionals and managers frequently spend significant time consolidating weekly activities, achievements, risks and priorities into a concise management summary.

Common challenges include:

- Collecting information from multiple sources.
- Separating important developments from routine activity.
- Identifying risks and blockers.
- Maintaining consistent reporting.
- Preparing concise executive communication.

## Business Objective

Produce a concise weekly management summary that highlights meaningful progress, significant developments, risks, decisions and upcoming priorities.

The Weekly Leadership Summary System provides a structured methodology for preparing concise executive summaries that communicate organizational progress, strategic initiatives, operational risks and key decisions.

Its purpose is to replace lengthy weekly reports with decision-oriented summaries that executives can review in just a few minutes while maintaining complete visibility into business priorities.

---

# Business Problem

Leadership teams receive information from multiple departments in different formats.

Typical consequences include:

- Information overload.
- Delayed executive decisions.
- Inconsistent reporting.
- Lack of organizational visibility.
- Duplicate communications.
- Reduced management effectiveness.

---

# Business Objective

Create standardized weekly executive summaries that consolidate business performance, project progress, operational status and strategic priorities into a single leadership report.

---

# Typical Enterprise Scenario

An executive committee receives weekly updates from several business units including Operations, Technology, Finance, Sales and Human Resources.

Instead of reviewing multiple reports independently, leadership requires one consolidated executive summary highlighting:

- Major achievements.
- Critical risks.
- Strategic initiatives.
- Decisions required.
- Priorities for the coming week.

---

# Professional AI Workflow

## Step 1 — Collect Weekly Information

Gather:

- Department updates
- KPI results
- Project status
- Operational incidents
- Financial highlights
- Customer feedback
- Strategic initiatives

---

## Step 2 — Consolidate Information

Group information into:

- Business Performance
- Operational Performance
- Strategic Initiatives
- Financial Overview
- Customer Highlights
- Organizational Updates

Remove duplicate information.

---

## Step 3 — Identify Executive Priorities

Highlight:

- Significant achievements
- Emerging risks
- Critical issues
- Required executive decisions
- Upcoming milestones

---

## Step 4 — Analyze Business Impact

For each major topic explain:

- Why it matters.
- Expected impact.
- Dependencies.
- Recommended actions.
- Responsible owners.

---

## Step 5 — Executive Dashboard

Summarize:

- Overall organizational health
- KPI trends
- Risk indicators
- Strategic progress
- Operational performance

---

## Step 6 — Recommendations

Provide:

- Immediate actions
- Strategic recommendations
- Escalation items
- Decisions required
- Next-week priorities

---

## Step 7 — Leadership Review

Verify:

- Clarity
- Accuracy
- Completeness
- Executive readability
- Action orientation

---

# Professional AI Prompt

You are a Chief of Staff preparing the Weekly Leadership Summary for the executive committee.

Generate:

- Executive Summary
- Organizational Highlights
- KPI Overview
- Strategic Initiatives
- Operational Performance
- Financial Highlights
- Risks
- Decisions Required
- Priorities for Next Week
- Executive Recommendations

Write using concise executive language suitable for C-Level leadership.

---

# Required Input Information

Collect:

- Weekly KPIs
- Department reports
- Financial indicators
- Project summaries
- Operational incidents
- Customer metrics
- Business risks
- Strategic initiatives
- Executive requests

---

# Expected Deliverables

Generate:

- Weekly Leadership Summary
- Executive Dashboard
- KPI Summary
- Strategic Overview
- Operational Highlights
- Executive Action List
- Decision Register

---

# Validation Checklist

Verify:

- Reporting period defined.
- KPIs updated.
- Strategic initiatives summarized.
- Risks documented.
- Decisions identified.
- Executive recommendations included.
- Priorities clearly defined.
- Report suitable for executive review.

---

# Common Mistakes

Avoid:

- Repeating departmental reports verbatim.
- Including unnecessary operational detail.
- Omitting business impact.
- Mixing completed work with future plans.
- Providing data without interpretation.
- Producing reports without recommended actions.

---

# Best Practices

- Focus on strategic information.
- Use measurable business indicators.
- Highlight trends rather than isolated events.
- Present only actionable information.
- Keep the report concise.
- End with clear executive priorities.

---

# Business Value

Organizations benefit from:

- Faster executive alignment.
- Better strategic visibility.
- Improved governance.
- More effective weekly leadership meetings.
- Increased organizational transparency.
- Higher quality executive decisions.

---

# Estimated Time Savings

Estimated reduction:

**2 to 4 hours every week while improving executive communication quality and consistency.**

---

# Expert Recommendations

An executive summary should help leadership understand the organization's current situation in less than ten minutes.

Every section should answer:

- What happened?
- Why is it important?
- What should leadership do next?

The objective is not to report everything, but to communicate what matters most for effective executive decision-making.

---

# Executive Email Assistant System

## Executive Summary


## Business Problem

High-impact business communication often requires careful consideration of audience, tone, clarity and desired action.

Common challenges include:

- Writing concise executive messages.
- Adapting technical information for business audiences.
- Communicating sensitive issues clearly.
- Maintaining professional tone.
- Making required actions explicit.
- Avoiding unnecessary detail.

## Business Objective

Create clear, concise and professionally structured executive communications that communicate the intended message, business context and required action effectively.

The Executive Email Assistant System provides a structured methodology for drafting professional executive communications that are clear, concise and aligned with organizational objectives.

Its purpose is to reduce the time executives spend writing high-impact communications while improving consistency, professionalism and decision-oriented messaging.

Rather than simply correcting grammar, this system helps transform business ideas into executive-quality communications.

---

# Business Problem

Executive leaders exchange hundreds of emails every month involving strategic decisions, stakeholder communications, approvals and organizational updates.

Common challenges include:

- Time-consuming drafting.
- Inconsistent communication style.
- Unclear action requests.
- Excessive technical detail.
- Ambiguous expectations.
- Missing executive summaries.

---

# Business Objective

Create executive emails that communicate business objectives clearly, establish accountability and facilitate rapid decision-making.

---

# Typical Enterprise Scenario

An executive must communicate a strategic initiative involving multiple departments.

The communication should:

- Explain the business context.
- Define expectations.
- Assign responsibilities.
- Establish timelines.
- Request executive actions.

The recipients include senior managers, project leaders and business stakeholders.

---

# Professional AI Workflow

## Step 1 — Communication Context

Document:

- Email objective
- Sender
- Audience
- Business initiative
- Priority
- Required action

---

## Step 2 — Audience Analysis

Identify:

- Executive recipients
- Business managers
- Technical leaders
- Operational teams
- External stakeholders

Adjust language according to the audience.

---

## Step 3 — Executive Structure

Prepare the email using:

- Subject
- Executive Opening
- Business Context
- Current Situation
- Required Action
- Deadlines
- Responsibilities
- Closing Summary

---

## Step 4 — Action Definition

Clearly define:

- Owner
- Deliverable
- Due date
- Dependencies
- Expected outcome

---

## Step 5 — Executive Review

Validate:

- Clarity
- Professional tone
- Business alignment
- Actionability
- Brevity

---

# Professional AI Prompt

You are an Executive Communications Advisor.

Draft a professional executive email.

Include:

- Executive Subject
- Executive Opening
- Business Context
- Key Information
- Required Actions
- Responsibilities
- Timeline
- Closing Message

The communication must be concise, professional and action-oriented.

---

# Required Input Information

Collect:

- Communication objective
- Audience
- Business context
- Required actions
- Timeline
- Dependencies
- Risks
- Desired tone

---

# Expected Deliverables

Generate:

- Executive Email
- Alternative Subject Lines
- Executive Summary
- Action Items
- Responsibility Matrix
- Follow-up Recommendations

---

# Validation Checklist

Verify:

- Objective clearly stated.
- Audience appropriate.
- Required actions identified.
- Deadlines defined.
- Responsibilities assigned.
- Tone professional.
- Executive summary included.
- Closing action clear.

---

# Common Mistakes

Avoid:

- Long introductions.
- Unclear action requests.
- Excessive technical language.
- Missing deadlines.
- Undefined ownership.
- Multiple unrelated topics.

---

# Best Practices

- One objective per email.
- Start with the business outcome.
- Use short paragraphs.
- Highlight required actions.
- Define deadlines explicitly.
- End with a clear call to action.

---

# Business Value

Organizations benefit from:

- Faster executive communication.
- Better accountability.
- Improved decision execution.
- Reduced misunderstandings.
- Higher communication consistency.
- Stronger executive alignment.

---

# Estimated Time Savings

Estimated reduction:

**15 to 30 minutes per executive email while improving communication quality and consistency.**

---

# Expert Recommendations

Executive emails should answer three questions immediately:

- Why am I receiving this?
- What is expected from me?
- By when must I act?

If recipients cannot answer those questions after reading the first few paragraphs, the communication should be revised.

Every executive email should drive action, not simply distribute information.

---

# Strategic Meeting Preparation System

## Executive Summary


## Business Problem

Important meetings often fail to produce their intended outcomes because participants lack a structured agenda, relevant context, decision criteria or clearly defined actions.

Common challenges include:

- Unclear meeting objectives.
- Excessive discussion without decisions.
- Missing stakeholder context.
- Poor preparation.
- Unclear responsibilities.
- Actions that are not documented or followed up.

## Business Objective

Prepare a structured meeting package that establishes objectives, participants, agenda, required information, decision points and expected outcomes before the meeting begins.

The Strategic Meeting Preparation System provides a structured methodology for planning, organizing and facilitating executive meetings that lead to informed decisions, clear accountability and measurable business outcomes.

Rather than simply creating an agenda, this system prepares leadership with the context, analysis and decision support required to maximize the value of every strategic meeting.

---

# Business Problem

Executive meetings often consume significant time without producing clear decisions or actionable outcomes.

Common consequences include:

- Unclear objectives.
- Repeated discussions.
- Delayed decisions.
- Undefined responsibilities.
- Incomplete preparation.
- Low meeting effectiveness.
- Poor follow-up.

---

# Business Objective

Prepare comprehensive meeting materials that allow executives to arrive informed, evaluate strategic alternatives efficiently and conclude every meeting with documented decisions and assigned actions.

---

# Typical Enterprise Scenario

An executive committee meets every Monday to review organizational performance, strategic initiatives and operational risks.

Participants include:

- Executive Leadership
- Business Directors
- Technology Leadership
- Finance
- Operations
- Project Management Office

Each participant requires concise information focused on decision-making rather than operational detail.

---

# Professional AI Workflow

## Step 1 — Define Meeting Purpose

Document:

- Meeting title
- Business objective
- Strategic importance
- Meeting owner
- Participants
- Expected outcomes

---

## Step 2 — Executive Context

Summarize:

- Current business situation
- Progress since previous meeting
- Major achievements
- Significant changes
- Executive priorities

---

## Step 3 — Agenda Preparation

Organize the meeting into:

1. Executive Overview

2. Strategic Updates

3. Business Performance

4. Operational Risks

5. Project Highlights

6. Decisions Required

7. Next Steps

Assign estimated time for every agenda item.

---

## Step 4 — Decision Support Material

Prepare for every discussion:

- Business background
- Current status
- Supporting metrics
- Available alternatives
- Advantages
- Risks
- Financial impact
- Recommendation

---

## Step 5 — Risk Review

Identify:

- Strategic risks
- Operational risks
- Financial risks
- Regulatory risks
- Resource constraints

Document mitigation proposals.

---

## Step 6 — Action Register

For every approved action define:

- Description
- Owner
- Priority
- Due date
- Success criteria
- Dependencies

---

## Step 7 — Meeting Summary

Prepare:

- Decisions made
- Approved actions
- Deferred topics
- Outstanding questions
- Executive commitments
- Follow-up schedule

---

# Professional AI Prompt

You are a Chief of Staff preparing a Strategic Executive Meeting.

Generate:

- Executive Brief
- Meeting Agenda
- Business Context
- Executive Dashboard
- Strategic Updates
- Risk Summary
- Decision Matrix
- Recommendations
- Action Register
- Executive Summary
- Meeting Follow-up

Write using concise executive language appropriate for senior leadership.

---

# Required Input Information

Collect:

- Meeting objective
- Participants
- Business priorities
- Current KPIs
- Strategic initiatives
- Open risks
- Project updates
- Financial highlights
- Decisions pending
- Time available

---

# Expected Deliverables

Generate:

- Executive Meeting Brief
- Meeting Agenda
- Executive Dashboard
- Decision Register
- Risk Summary
- Action Register
- Meeting Minutes Template
- Executive Follow-up Report

---

# Validation Checklist

Verify:

- Meeting objective defined.
- Participants identified.
- Agenda prioritized.
- Decision topics documented.
- Risks summarized.
- Recommendations prepared.
- Actions assigned.
- Follow-up process established.

---

# Common Mistakes

Avoid:

- Scheduling meetings without clear objectives.
- Including unnecessary participants.
- Spending excessive time on operational details.
- Discussing issues without decision proposals.
- Ending meetings without documented actions.
- Failing to assign ownership.

---

# Best Practices

- Distribute materials before the meeting.
- Begin with strategic priorities.
- Focus discussion on decisions.
- Time-box every agenda item.
- Record decisions in real time.
- Confirm ownership before closing the meeting.
- Review outstanding actions at the beginning of the next meeting.

---

# Business Value

Organizations benefit from:

- Shorter executive meetings.
- Better strategic alignment.
- Faster decision-making.
- Increased accountability.
- Improved governance.
- More effective follow-up.
- Higher executive productivity.

---

# Estimated Time Savings

Estimated reduction:

**2 to 5 hours of executive preparation and follow-up per strategic meeting while significantly improving decision quality and execution.**

---

# Expert Recommendations

Executive meetings should exist to produce decisions, not presentations.

Every agenda item should conclude with one of the following outcomes:

- Decision approved.
- Additional information requested.
- Action assigned.
- Risk accepted.
- Topic deferred with justification.

If none of these outcomes is achieved, the discussion should be reconsidered or removed from future agendas.

A successful strategic meeting ends with complete clarity regarding responsibilities, timelines and expected business outcomes.

---
